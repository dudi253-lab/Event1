import crypto from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin, validStaffToken } from '@/lib/supabase-admin';

function safeName(name: string) {
  return name
    .normalize('NFKD')
    .replace(/[^\w.\-]+/g, '-')
    .replace(/-+/g, '-')
    .slice(-100) || 'photo.jpg';
}

function clientHash(request: NextRequest) {
  const raw =
    request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
    request.headers.get('x-real-ip') ||
    'unknown';
  return crypto.createHash('sha256').update(raw).digest('hex');
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const kind = body?.kind === 'cover' ? 'cover' : 'guest';
    const eventId = String(body?.eventId || '');
    const sessionToken = String(body?.sessionToken || '');
    const fileName = safeName(String(body?.fileName || 'photo.jpg'));
    const contentHash = body?.contentHash ? String(body.contentHash) : null;

    if (!eventId) {
      return NextResponse.json({ error: 'אירוע לא תקין.' }, { status: 400 });
    }

    const admin = getSupabaseAdmin();

    if (kind === 'cover') {
      const ok = sessionToken && await validStaffToken(sessionToken, eventId, ['company_admin']);
      if (!ok) return NextResponse.json({ error: 'אין הרשאת מנהל.' }, { status: 403 });
    } else {
      const { data: event } = await admin
        .from('events')
        .select('id,status')
        .eq('id', eventId)
        .maybeSingle();

      const { data: settings } = await admin
        .from('event_settings')
        .select('uploads_enabled,max_photos_per_upload')
        .eq('event_id', eventId)
        .maybeSingle();

      if (!event || !settings?.uploads_enabled || !['ready', 'live', 'post_event'].includes(event.status)) {
        return NextResponse.json({ error: 'העלאת תמונות אינה פעילה כרגע.' }, { status: 403 });
      }

      if (contentHash) {
        const { data: duplicate } = await admin
          .from('photos')
          .select('id')
          .eq('event_id', eventId)
          .eq('content_hash', contentHash)
          .limit(1)
          .maybeSingle();

        if (duplicate) {
          return NextResponse.json({ duplicate: true });
        }
      }

      const hash = clientHash(request);
      const since = new Date(Date.now() - 60 * 60 * 1000).toISOString();
      const { count } = await admin
        .from('upload_ticket_log')
        .select('id', { count: 'exact', head: true })
        .eq('event_id', eventId)
        .eq('client_hash', hash)
        .gte('created_at', since);

      if ((count || 0) >= 120) {
        return NextResponse.json({ error: 'בוצעו יותר מדי העלאות בזמן קצר. נסו שוב מאוחר יותר.' }, { status: 429 });
      }

      await admin.from('upload_ticket_log').insert({ event_id: eventId, client_hash: hash });
    }

    const bucket = kind === 'cover' ? 'event-assets' : 'event-photos';
    const folder = kind === 'cover' ? 'covers' : 'pending';
    const path = `events/${eventId}/${folder}/${crypto.randomUUID()}-${fileName}`;

    const { data, error } = await admin.storage.from(bucket).createSignedUploadUrl(path);
    if (error || !data?.token) throw error || new Error('No upload token');

    return NextResponse.json({
      path,
      token: data.token,
      bucket,
      duplicate: false,
    });
  } catch (error) {
    console.error('upload-ticket route', error);
    return NextResponse.json({ error: 'לא הצלחנו להכין את ההעלאה.' }, { status: 500 });
  }
}
