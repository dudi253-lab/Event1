import { createClient } from '@supabase/supabase-js';

export function getSupabaseAdmin() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url || !serviceKey) {
    throw new Error('Digi server configuration is incomplete.');
  }

  return createClient(url, serviceKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

export async function validStaffToken(
  token: string,
  eventId: string,
  allowedRoles: Array<'company_admin' | 'photo_moderator'>,
) {
  const admin = getSupabaseAdmin();
  const { data: session, error } = await admin
    .from('staff_sessions')
    .select('token,user_id,event_id,role,expires_at')
    .eq('token', token)
    .gt('expires_at', new Date().toISOString())
    .maybeSingle();

  if (error || !session || !allowedRoles.includes(session.role)) return false;

  if (session.role === 'photo_moderator') {
    return session.event_id === eventId;
  }

  if (!session.user_id) return false;

  const { data: event } = await admin
    .from('events')
    .select('company_id')
    .eq('id', eventId)
    .maybeSingle();

  if (!event) return false;

  const { data: membership } = await admin
    .from('company_users')
    .select('id')
    .eq('user_id', session.user_id)
    .eq('company_id', event.company_id)
    .eq('active', true)
    .maybeSingle();

  return Boolean(membership);
}
