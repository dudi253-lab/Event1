-- Digi v0.4 — complete multi-event migration
-- Run AFTER schema.sql, v0.2.sql and v0.3.sql.
-- Safe to run once on the existing Digi project.

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------------
-- Multi-event identity + future-ready metadata
-- ---------------------------------------------------------------------------

alter table public.events add column if not exists public_id text;
alter table public.events add column if not exists timezone text not null default 'Asia/Jerusalem';

update public.events
set public_id = upper(substr(encode(gen_random_bytes(8), 'hex'), 1, 10))
where public_id is null;

alter table public.events
  alter column public_id set default upper(substr(encode(gen_random_bytes(8), 'hex'), 1, 10));
alter table public.events alter column public_id set not null;
create unique index if not exists events_public_id_uidx on public.events(public_id);

alter table public.photos add column if not exists content_hash text;
create unique index if not exists photos_event_hash_uidx
  on public.photos(event_id, content_hash)
  where content_hash is not null;

alter table public.event_settings add column if not exists retention_days integer not null default 90;
alter table public.event_settings add column if not exists locale text not null default 'he-IL';

-- Moderator PIN belongs to the event, so one event cannot open another.
alter table public.event_staff add column if not exists pin_hash text;

update public.event_staff es
set pin_hash = u.pin_hash
from public.users u
where u.id = es.user_id
  and es.pin_hash is null
  and u.pin_hash is not null;

-- Company-admin sessions are global; moderator sessions remain event-scoped.
alter table public.staff_sessions alter column event_id drop not null;

-- ---------------------------------------------------------------------------
-- Audit log
-- ---------------------------------------------------------------------------

create table if not exists public.photo_moderation_log (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.events(id) on delete cascade,
  photo_id uuid not null references public.photos(id) on delete cascade,
  from_status photo_status not null,
  to_status photo_status not null,
  actor_user_id uuid references public.users(id) on delete set null,
  actor_role text not null check (actor_role in ('company_admin','photo_moderator')),
  created_at timestamptz not null default now()
);

create index if not exists moderation_log_event_idx
  on public.photo_moderation_log(event_id, created_at desc);

alter table public.photo_moderation_log enable row level security;
revoke all on public.photo_moderation_log from anon, authenticated;

-- ---------------------------------------------------------------------------
-- Global admin login
-- ---------------------------------------------------------------------------

create or replace function public.company_admin_pin_login(p_pin text)
returns table (
  token uuid,
  user_id uuid,
  user_name text,
  role text,
  company_id uuid
)
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_user_id uuid;
  v_company_id uuid;
  v_user_name text;
  v_token uuid := gen_random_uuid();
begin
  if p_pin !~ '^\d{4}$' then
    raise exception 'הקוד אינו נכון';
  end if;

  delete from public.staff_sessions where expires_at < now();

  select u.id, u.name, cu.company_id
    into v_user_id, v_user_name, v_company_id
  from public.users u
  join public.company_users cu
    on cu.user_id = u.id
   and cu.active = true
   and cu.role = 'company_admin'
  where u.active = true
    and u.pin_hash is not null
    and crypt(p_pin, u.pin_hash) = u.pin_hash
  limit 1;

  if v_user_id is null or v_company_id is null then
    raise exception 'הקוד אינו נכון';
  end if;

  insert into public.staff_sessions (token, user_id, event_id, role)
  values (v_token, v_user_id, null, 'company_admin');

  return query
  select v_token, v_user_id, v_user_name, 'company_admin'::text, v_company_id;
end;
$$;

grant execute on function public.company_admin_pin_login(text) to anon, authenticated;

-- Global admin tokens work on every event in their company.
create or replace function public.valid_staff_session(
  p_token uuid,
  p_event_id uuid,
  p_roles text[]
)
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.staff_sessions s
    left join public.users u on u.id = s.user_id
    where s.token = p_token
      and s.expires_at > now()
      and s.role = any(p_roles)
      and (
        (
          s.role = 'photo_moderator'
          and s.event_id = p_event_id
          and (s.user_id is null or coalesce(u.active, false))
        )
        or
        (
          s.role = 'company_admin'
          and coalesce(u.active, false)
          and exists (
            select 1
            from public.company_users cu
            join public.events e on e.company_id = cu.company_id
            where cu.user_id = s.user_id
              and cu.active = true
              and e.id = p_event_id
          )
        )
      )
  );
$$;

revoke all on function public.valid_staff_session(uuid, uuid, text[]) from public, anon, authenticated;
grant execute on function public.valid_staff_session(uuid, uuid, text[]) to service_role;

-- Event-specific moderator login.
create or replace function public.staff_pin_login(
  p_pin text,
  p_role text,
  p_event_id uuid
)
returns table (
  token uuid,
  user_id uuid,
  user_name text,
  role text
)
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_user_id uuid;
  v_user_name text;
  v_token uuid := gen_random_uuid();
begin
  if p_pin !~ '^\d{4}$' then
    raise exception 'הקוד אינו נכון';
  end if;

  delete from public.staff_sessions where expires_at < now();

  if p_role = 'company_admin' then
    select u.id, u.name
      into v_user_id, v_user_name
    from public.users u
    join public.company_users cu on cu.user_id = u.id and cu.active = true
    join public.events e on e.company_id = cu.company_id
    where e.id = p_event_id
      and u.active = true
      and u.pin_hash is not null
      and crypt(p_pin, u.pin_hash) = u.pin_hash
    limit 1;
  elsif p_role = 'photo_moderator' then
    select u.id, u.name
      into v_user_id, v_user_name
    from public.users u
    join public.event_staff es on es.user_id = u.id and es.active = true
    where es.event_id = p_event_id
      and u.active = true
      and es.pin_hash is not null
      and crypt(p_pin, es.pin_hash) = es.pin_hash
    limit 1;
  else
    raise exception 'תפקיד לא תקין';
  end if;

  if v_user_id is null then
    raise exception 'הקוד אינו נכון';
  end if;

  insert into public.staff_sessions (token, user_id, event_id, role)
  values (v_token, v_user_id, p_event_id, p_role);

  return query
  select v_token, v_user_id, v_user_name, p_role;
end;
$$;

grant execute on function public.staff_pin_login(text, text, uuid) to anon, authenticated;

-- ---------------------------------------------------------------------------
-- Public event + admin event collection
-- ---------------------------------------------------------------------------

create or replace function public.list_company_events(p_token uuid)
returns setof public.events
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid;
begin
  select s.user_id into v_user_id
  from public.staff_sessions s
  where s.token = p_token
    and s.role = 'company_admin'
    and s.expires_at > now()
  limit 1;

  if v_user_id is null then
    raise exception 'אין הרשאת מנהל';
  end if;

  return query
  select e.*
  from public.events e
  join public.company_users cu on cu.company_id = e.company_id
  where cu.user_id = v_user_id
    and cu.active = true
  order by e.event_date desc nulls last, e.created_at desc;
end;
$$;

grant execute on function public.list_company_events(uuid) to anon, authenticated;

create or replace function public.create_company_event(
  p_token uuid,
  p_name text,
  p_event_type text,
  p_event_date date,
  p_moderator_pin text
)
returns setof public.events
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_admin_user_id uuid;
  v_company_id uuid;
  v_event_id uuid := gen_random_uuid();
  v_moderator_user_id uuid := gen_random_uuid();
  v_public_id text := upper(substr(encode(gen_random_bytes(8), 'hex'), 1, 10));
  v_slug text;
begin
  if trim(coalesce(p_name, '')) = '' then
    raise exception 'חסר שם אירוע';
  end if;

  if p_moderator_pin !~ '^\d{4}$' then
    raise exception 'קוד השושבינות חייב להכיל 4 ספרות';
  end if;

  select s.user_id, cu.company_id
    into v_admin_user_id, v_company_id
  from public.staff_sessions s
  join public.company_users cu on cu.user_id = s.user_id and cu.active = true
  where s.token = p_token
    and s.role = 'company_admin'
    and s.expires_at > now()
  limit 1;

  if v_admin_user_id is null or v_company_id is null then
    raise exception 'אין הרשאת מנהל';
  end if;

  v_slug := 'event-' || lower(v_public_id);

  insert into public.events (
    id, company_id, name, event_type, event_date, status, slug, public_id
  ) values (
    v_event_id, v_company_id, left(trim(p_name), 80),
    left(coalesce(nullif(trim(p_event_type), ''), 'אירוע'), 50),
    p_event_date, 'draft', v_slug, v_public_id
  );

  insert into public.event_settings (
    event_id, moderation_required, uploads_enabled, album_enabled,
    downloads_enabled, max_photos_per_upload
  ) values (
    v_event_id, true, true, true, true, 20
  );

  insert into public.users (id, name, phone, active)
  values (
    v_moderator_user_id,
    'שושבינות · ' || left(trim(p_name), 60),
    'digi-event-' || v_event_id::text,
    true
  );

  insert into public.event_staff (event_id, user_id, role, active, pin_hash)
  values (
    v_event_id, v_moderator_user_id, 'photo_moderator', true,
    crypt(p_moderator_pin, gen_salt('bf'))
  );

  insert into public.access_points (event_id, name, type, active)
  values (v_event_id, 'Digi QR / NFC', 'both', true);

  return query select e.* from public.events e where e.id = v_event_id;
end;
$$;

grant execute on function public.create_company_event(uuid, text, text, date, text) to anon, authenticated;

create or replace function public.set_event_moderator_pin(
  p_token uuid,
  p_event_id uuid,
  p_pin text
)
returns void
language plpgsql
security definer
set search_path = public, extensions
as $$
begin
  if p_pin !~ '^\d{4}$' then
    raise exception 'הקוד חייב להכיל 4 ספרות';
  end if;

  if not public.valid_staff_session(p_token, p_event_id, array['company_admin']) then
    raise exception 'אין הרשאת מנהל';
  end if;

  update public.event_staff
  set pin_hash = crypt(p_pin, gen_salt('bf'))
  where event_id = p_event_id
    and role = 'photo_moderator'
    and active = true;
end;
$$;

grant execute on function public.set_event_moderator_pin(uuid, uuid, text) to anon, authenticated;

create or replace function public.update_event_v04(
  p_token uuid,
  p_event_id uuid,
  p_name text,
  p_event_type text,
  p_event_date date,
  p_location text,
  p_status event_status,
  p_cover_image text default null
)
returns setof public.events
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.valid_staff_session(p_token, p_event_id, array['company_admin']) then
    raise exception 'אין הרשאת מנהל';
  end if;

  return query
  update public.events
  set
    name = left(coalesce(nullif(trim(p_name), ''), name), 80),
    event_type = left(coalesce(nullif(trim(p_event_type), ''), event_type, 'אירוע'), 50),
    event_date = p_event_date,
    location = left(nullif(trim(coalesce(p_location, '')), ''), 160),
    status = p_status,
    cover_image = coalesce(nullif(trim(p_cover_image), ''), cover_image),
    updated_at = now()
  where id = p_event_id
  returning *;
end;
$$;

grant execute on function public.update_event_v04(uuid, uuid, text, text, date, text, event_status, text)
  to anon, authenticated;

create or replace function public.event_health(
  p_token uuid,
  p_event_id uuid
)
returns table (
  moderator_ready boolean,
  settings_ready boolean,
  cover_ready boolean,
  public_link_ready boolean
)
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.valid_staff_session(p_token, p_event_id, array['company_admin']) then
    raise exception 'אין הרשאת מנהל';
  end if;

  return query
  select
    exists(
      select 1 from public.event_staff es
      where es.event_id = p_event_id
        and es.active = true
        and es.pin_hash is not null
    ),
    exists(
      select 1 from public.event_settings s
      where s.event_id = p_event_id
        and s.album_enabled = true
    ),
    exists(
      select 1 from public.events e
      where e.id = p_event_id
        and e.cover_image is not null
    ),
    exists(
      select 1 from public.events e
      where e.id = p_event_id
        and e.public_id is not null
    );
end;
$$;

grant execute on function public.event_health(uuid, uuid) to anon, authenticated;

-- ---------------------------------------------------------------------------
-- Safer moderation: expected status prevents two moderators acting on one card.
-- ---------------------------------------------------------------------------

create or replace function public.moderate_photo_v04(
  p_token uuid,
  p_photo_id uuid,
  p_status photo_status,
  p_expected_status photo_status default null
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_event_id uuid;
  v_current_status photo_status;
  v_user_id uuid;
  v_role text;
begin
  select p.event_id, p.status
    into v_event_id, v_current_status
  from public.photos p
  where p.id = p_photo_id
  for update;

  if v_event_id is null then
    raise exception 'התמונה לא נמצאה';
  end if;

  if not public.valid_staff_session(
    p_token, v_event_id, array['photo_moderator','company_admin']
  ) then
    raise exception 'אין הרשאה לתמונה הזו';
  end if;

  if p_expected_status is not null and v_current_status <> p_expected_status then
    raise exception 'התמונה כבר טופלה על ידי משתמש אחר';
  end if;

  select s.user_id, s.role into v_user_id, v_role
  from public.staff_sessions s
  where s.token = p_token
    and s.expires_at > now()
  limit 1;

  update public.photos
  set
    status = p_status,
    moderated_at = case when p_status = 'pending' then null else now() end,
    moderated_by = case when p_status = 'pending' then null else v_user_id end
  where id = p_photo_id;

  insert into public.photo_moderation_log(
    event_id, photo_id, from_status, to_status, actor_user_id, actor_role
  ) values (
    v_event_id, p_photo_id, v_current_status, p_status, v_user_id, v_role
  );
end;
$$;

grant execute on function public.moderate_photo_v04(uuid, uuid, photo_status, photo_status)
  to anon, authenticated;

-- v0.4 stats include storage estimate.
create or replace function public.event_stats_v04(
  p_token uuid,
  p_event_id uuid
)
returns table (
  total bigint,
  pending bigint,
  approved bigint,
  private_count bigint,
  rejected bigint,
  storage_bytes bigint
)
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.valid_staff_session(
    p_token, p_event_id, array['photo_moderator','company_admin']
  ) then
    raise exception 'אין הרשאה לנתוני האירוע';
  end if;

  return query
  select
    count(*)::bigint,
    count(*) filter (where p.status = 'pending')::bigint,
    count(*) filter (where p.status = 'approved')::bigint,
    count(*) filter (where p.status = 'private')::bigint,
    count(*) filter (where p.status = 'rejected')::bigint,
    coalesce(sum(p.file_size), 0)::bigint
  from public.photos p
  where p.event_id = p_event_id;
end;
$$;

grant execute on function public.event_stats_v04(uuid, uuid) to anon, authenticated;


-- Hashed-IP upload ticket log for lightweight abuse throttling.
create table if not exists public.upload_ticket_log (
  id bigserial primary key,
  event_id uuid not null references public.events(id) on delete cascade,
  client_hash text not null,
  created_at timestamptz not null default now()
);
create index if not exists upload_ticket_log_lookup_idx
  on public.upload_ticket_log(event_id, client_hash, created_at desc);
alter table public.upload_ticket_log enable row level security;
revoke all on public.upload_ticket_log from anon, authenticated;

-- ---------------------------------------------------------------------------
-- RLS: approved metadata public, pending writes validated by event settings.
-- ---------------------------------------------------------------------------

alter table public.events enable row level security;
drop policy if exists public_read_events on public.events;
create policy public_read_events
on public.events for select
to anon, authenticated
using (true);
grant select on public.events to anon, authenticated;

alter table public.photos enable row level security;
grant select, insert on public.photos to anon, authenticated;

drop policy if exists public_read_approved_photos on public.photos;
create policy public_read_approved_photos
on public.photos for select
to anon, authenticated
using (status = 'approved');

drop policy if exists guest_insert_pending_photos on public.photos;
create policy guest_insert_pending_photos
on public.photos for insert
to anon, authenticated
with check (
  status = 'pending'
  and exists (
    select 1
    from public.events e
    join public.event_settings s on s.event_id = e.id
    where e.id = photos.event_id
      and e.status in ('ready','live','post_event')
      and s.uploads_enabled = true
  )
);

-- Sensitive staff tables remain RPC-only.
revoke select on public.users from anon, authenticated;
revoke select on public.event_staff from anon, authenticated;

-- ---------------------------------------------------------------------------
-- Storage
-- event-photos is PRIVATE in v0.4; the Next.js server returns short-lived URLs.
-- event-assets stays public because event covers are intentionally public.
-- ---------------------------------------------------------------------------

update storage.buckets set public = false where id = 'event-photos';
update storage.buckets set public = true where id = 'event-assets';

drop policy if exists guest_upload_event_photos on storage.objects;
drop policy if exists staff_upload_event_assets on storage.objects;

-- Uploads in v0.4 use server-created signed upload tickets, so no broad anon
-- storage INSERT policy is required.

alter table public.events replica identity full;
alter table public.photos replica identity full;
