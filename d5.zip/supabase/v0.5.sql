-- Digi v0.5 — upload reliability + social sticker metadata
-- Run AFTER v0.4. Safe to run more than once.

create extension if not exists pgcrypto;

-- Store non-destructive edit metadata alongside the flattened image.
alter table public.photos
  add column if not exists edit_metadata jsonb not null default '{}'::jsonb;

-- Every event must have settings. This repairs older/demo events that may be
-- missing a row after previous development migrations.
insert into public.event_settings (
  event_id,
  moderation_required,
  uploads_enabled,
  album_enabled,
  downloads_enabled,
  max_photos_per_upload
)
select
  e.id,
  true,
  case when e.status in ('ready','live','post_event') then true else false end,
  true,
  true,
  20
from public.events e
where not exists (
  select 1 from public.event_settings s where s.event_id = e.id
)
on conflict (event_id) do nothing;

-- v0.5 intentionally opens uploads for every currently active event.
-- Draft/archived events remain closed by the API route and RLS policy.
update public.event_settings s
set uploads_enabled = true,
    updated_at = now()
where exists (
  select 1
  from public.events e
  where e.id = s.event_id
    and e.status in ('ready','live','post_event')
);

-- Keep guest inserts limited to pending photos belonging to an active event.
alter table public.photos enable row level security;
grant select, insert on public.photos to anon, authenticated;

drop policy if exists guest_insert_pending_photos on public.photos;
create policy guest_insert_pending_photos
on public.photos
for insert
to anon, authenticated
with check (
  status = 'pending'
  and exists (
    select 1
    from public.events e
    join public.event_settings s on s.event_id = e.id
    where e.id = photos.event_id
      and e.status in ('ready','live','post_event')
      and s.uploads_enabled = true
  )
);

-- Approved photos remain the only rows readable by guests.
drop policy if exists public_read_approved_photos on public.photos;
create policy public_read_approved_photos
on public.photos
for select
to anon, authenticated
using (status = 'approved');

-- Private originals continue to be served through short-lived signed URLs.
update storage.buckets set public = false where id = 'event-photos';
update storage.buckets set public = true where id = 'event-assets';

-- Realtime remains enabled for events + photos.
alter table public.events replica identity full;
alter table public.photos replica identity full;

do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    if not exists (
      select 1 from pg_publication_tables
      where pubname='supabase_realtime' and schemaname='public' and tablename='events'
    ) then
      alter publication supabase_realtime add table public.events;
    end if;
    if not exists (
      select 1 from pg_publication_tables
      where pubname='supabase_realtime' and schemaname='public' and tablename='photos'
    ) then
      alter publication supabase_realtime add table public.photos;
    end if;
  end if;
end $$;
