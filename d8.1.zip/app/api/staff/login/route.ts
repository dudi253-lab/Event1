import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase-admin';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const eventId = String(body?.eventId || '');
    const pin = String(body?.pin || '').replace(/\D/g, '').slice(0, 4);
    const role = body?.role === 'company_admin' ? 'company_admin' : 'photo_moderator';

    if (!eventId || pin.length !== 4) {
      return NextResponse.json({ error: 'הקוד אינו נכון.' }, { status: 400 });
    }

    const admin = getSupabaseAdmin();

    const rpc = role === 'photo_moderator'
      ? admin.rpc('digi_moderator_login_v081', {
          p_event_id: eventId,
          p_pin: pin,
        })
      : admin.rpc('digi_staff_login_v06', {
          p_pin: pin,
          p_role: role,
          p_event_id: eventId,
        });

    const { data, error } = await rpc;

    if (error) {
      console.error('staff login', error);
      return NextResponse.json({ error: 'הקוד אינו נכון.' }, { status: 401 });
    }

    const row = Array.isArray(data) ? data[0] : data;
    if (!row?.token) {
      return NextResponse.json({ error: 'הקוד אינו נכון.' }, { status: 401 });
    }

    return NextResponse.json({
      token: row.token,
      user_id: row.user_id,
      user_name: row.user_name,
      role: row.role,
    });
  } catch (error) {
    console.error('staff login route', error);
    return NextResponse.json({ error: 'לא הצלחנו לבצע כניסה.' }, { status: 500 });
  }
}
