import process from 'node:process';
import pg from 'pg';
const { Client } = pg;

function askHidden(prompt) {
  return new Promise((resolve) => {
    const input = process.stdin, output = process.stdout;
    let value = '';
    output.write(prompt);
    input.resume();
    input.setEncoding('utf8');
    if (input.isTTY && input.setRawMode) input.setRawMode(true);
    const onData = (char) => {
      if (char === '\u0003') process.exit(130);
      if (char === '\r' || char === '\n') {
        if (input.isTTY && input.setRawMode) input.setRawMode(false);
        input.pause();
        input.off('data', onData);
        output.write('\n');
        resolve(value);
        return;
      }
      if (char === '\u007f' || char === '\b') { value = value.slice(0, -1); return; }
      value += char;
    };
    input.on('data', onData);
  });
}

const sql = `
drop policy if exists digi_guest_signed_upload_insert on storage.objects;
create policy digi_guest_signed_upload_insert
on storage.objects for insert to anon, authenticated
with check (
  bucket_id='event-photos'
  and (storage.foldername(name))[1]='events'
  and (storage.foldername(name))[3]='pending'
);

drop policy if exists digi_guest_signed_upload_select on storage.objects;
create policy digi_guest_signed_upload_select
on storage.objects for select to anon, authenticated
using (
  bucket_id='event-photos'
  and (storage.foldername(name))[1]='events'
  and (storage.foldername(name))[3]='pending'
);
`;

const password = await askHidden('DB password: ');
const client = new Client({
  host: 'aws-0-eu-central-2.pooler.supabase.com',
  port: 5432,
  database: 'postgres',
  user: 'postgres.fhlirqpqqvaudhighkww',
  password,
  ssl: { rejectUnauthorized: false },
});

try {
  await client.connect();
  await client.query(sql);
  console.log('✅ Storage fixed');
} catch (error) {
  console.error('❌', error?.message || error);
  process.exitCode = 1;
} finally {
  await client.end().catch(() => {});
}
