-- Digi v0.8 — consolidated event-photo platform migration
-- Run AFTER the existing Digi schema. Safe to run repeatedly.

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------------
-- Core columns / tables required by the v0.6 server-first flow
-- ---------------------------------------------------------------------------

alter table public.photos add column if not exists content_hash text;
alter table public.photos add column if not exists edit_metadata jsonb not null default '{}'::jsonb;
create unique index if not exists photos_event_hash_uidx
  on public.photos(event_id, content_hash)
  where content_hash is not null;

alter table public.event_staff add column if not exists pin_hash text;
alter table public.staff_sessions alter column event_id drop not null;

create table if not exists public.photo_moderation_log (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.events(id) on delete cascade,
  photo_id uuid not null references public.photos(id) on delete cascade,
  from_status photo_status not null,
  to_status photo_status not null,
  actor_user_id uuid references public.users(id) on delete set null,
  actor_role text not null check (actor_role in ('company_admin','photo_moderator')),
  created_at timestamptz not null default now()
);

create table if not exists public.upload_ticket_log (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.events(id) on delete cascade,
  client_hash text not null,
  created_at timestamptz not null default now()
);
create index if not exists upload_ticket_log_event_client_idx
  on public.upload_ticket_log(event_id, client_hash, created_at desc);

-- ---------------------------------------------------------------------------
-- Repair settings and demo moderator access
-- ---------------------------------------------------------------------------

insert into public.event_settings (
  event_id, moderation_required, uploads_enabled, album_enabled,
  downloads_enabled, max_photos_per_upload
)
select e.id, true,
       (e.status in ('ready','live','post_event')),
       true, true, 20
from public.events e
where not exists (select 1 from public.event_settings s where s.event_id=e.id)
on conflict (event_id) do nothing;

update public.event_settings s
set uploads_enabled = true,
    updated_at = now()
where exists (
  select 1 from public.events e
  where e.id=s.event_id and e.status in ('ready','live','post_event')
);

-- Carry legacy user PINs into event-scoped moderator PINs when needed.
update public.event_staff es
set pin_hash = u.pin_hash
from public.users u
where u.id = es.user_id
  and es.pin_hash is null
  and u.pin_hash is not null;

-- v0.8 never overwrites an event's chosen moderator PIN.

-- ---------------------------------------------------------------------------
-- Dedicated server-only moderator login. It creates an event-scoped session.
-- ---------------------------------------------------------------------------

create or replace function public.digi_staff_login_v06(
  p_pin text,
  p_role text,
  p_event_id uuid
)
returns table (
  token uuid,
  user_id uuid,
  user_name text,
  role text
)
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_user_id uuid;
  v_user_name text;
  v_token uuid := gen_random_uuid();
begin
  if p_pin !~ '^\d{4}$' then
    raise exception 'הקוד אינו נכון';
  end if;

  delete from public.staff_sessions where expires_at < now();

  if p_role = 'photo_moderator' then
    select u.id, u.name
      into v_user_id, v_user_name
    from public.event_staff es
    join public.users u on u.id = es.user_id
    where es.event_id = p_event_id
      and es.role = 'photo_moderator'
      and es.active = true
      and u.active = true
      and es.pin_hash is not null
      and crypt(p_pin, es.pin_hash) = es.pin_hash
    limit 1;
  elsif p_role = 'company_admin' then
    select u.id, u.name
      into v_user_id, v_user_name
    from public.users u
    join public.company_users cu on cu.user_id = u.id and cu.active = true
    join public.events e on e.company_id = cu.company_id
    where e.id = p_event_id
      and u.active = true
      and u.pin_hash is not null
      and crypt(p_pin, u.pin_hash) = u.pin_hash
    limit 1;
  else
    raise exception 'תפקיד לא תקין';
  end if;

  if v_user_id is null then
    raise exception 'הקוד אינו נכון';
  end if;

  insert into public.staff_sessions(token,user_id,event_id,role,expires_at)
  values(v_token,v_user_id,p_event_id,p_role,now()+interval '12 hours');

  return query select v_token,v_user_id,v_user_name,p_role;
end;
$$;

revoke all on function public.digi_staff_login_v06(text,text,uuid) from public, anon, authenticated;
grant execute on function public.digi_staff_login_v06(text,text,uuid) to service_role;

-- ---------------------------------------------------------------------------
-- Server role privileges. RLS stays enabled for public clients; server routes
-- use the service role after checking Digi's own session authorization.
-- ---------------------------------------------------------------------------

grant usage on schema public to service_role;
grant select on public.events, public.event_settings, public.users,
  public.company_users, public.event_staff, public.staff_sessions to service_role;
grant select, insert, update, delete on public.photos to service_role;
grant select, insert on public.photo_moderation_log, public.upload_ticket_log to service_role;

-- Guest clients no longer write photo rows directly in v0.6.
-- The /api/complete-upload route writes pending rows after Storage succeeds.
alter table public.photos enable row level security;
revoke insert on public.photos from anon, authenticated;
drop policy if exists guest_insert_pending_photos on public.photos;

-- Public album can only read approved database rows.
grant select on public.photos to anon, authenticated;
drop policy if exists public_read_approved_photos on public.photos;
create policy public_read_approved_photos
on public.photos for select to anon, authenticated
using (status='approved');

-- ---------------------------------------------------------------------------
-- Storage: private originals + signed guest upload path.
-- ---------------------------------------------------------------------------

update storage.buckets set public=false where id='event-photos';
update storage.buckets set public=true where id='event-assets';

drop policy if exists digi_guest_signed_upload_insert on storage.objects;
create policy digi_guest_signed_upload_insert
on storage.objects
for insert
to anon, authenticated
with check (
  bucket_id='event-photos'
  and (storage.foldername(name))[1]='events'
  and (storage.foldername(name))[3]='pending'
);

drop policy if exists digi_guest_signed_upload_select on storage.objects;
create policy digi_guest_signed_upload_select
on storage.objects
for select
to anon, authenticated
using (
  bucket_id='event-photos'
  and (storage.foldername(name))[1]='events'
  and (storage.foldername(name))[3]='pending'
);

-- Keep old broad upload policies from accidentally overriding the signed path.
drop policy if exists guest_upload_event_photos on storage.objects;

-- ---------------------------------------------------------------------------
-- Realtime for automatic album/moderator refresh.
-- ---------------------------------------------------------------------------

alter table public.events replica identity full;
alter table public.photos replica identity full;

do $$
begin
  if exists (select 1 from pg_publication where pubname='supabase_realtime') then
    if not exists (
      select 1 from pg_publication_tables
      where pubname='supabase_realtime' and schemaname='public' and tablename='events'
    ) then
      alter publication supabase_realtime add table public.events;
    end if;
    if not exists (
      select 1 from pg_publication_tables
      where pubname='supabase_realtime' and schemaname='public' and tablename='photos'
    ) then
      alter publication supabase_realtime add table public.photos;
    end if;
  end if;
end $$;


-- ---------------------------------------------------------------------------
-- v0.7 authoritative staff authorization.
-- The API calls this with the server service-role key. The function validates
-- the live session and the current event membership in one database operation.
-- ---------------------------------------------------------------------------

create or replace function public.digi_valid_staff_v07(
  p_token uuid,
  p_event_id uuid,
  p_roles text[]
)
returns table (
  token uuid,
  user_id uuid,
  event_id uuid,
  role text
)
language sql
security definer
set search_path = public
as $$
  select s.token, s.user_id, s.event_id, s.role
  from public.staff_sessions s
  join public.users u
    on u.id = s.user_id
   and u.active = true
  where s.token = p_token
    and s.expires_at > now()
    and s.role = any(p_roles)
    and (
      (
        s.role = 'photo_moderator'
        and s.event_id = p_event_id
        and exists (
          select 1
          from public.event_staff es
          where es.event_id = p_event_id
            and es.user_id = s.user_id
            and es.role = 'photo_moderator'
            and es.active = true
        )
      )
      or
      (
        s.role = 'company_admin'
        and exists (
          select 1
          from public.events e
          join public.company_users cu
            on cu.company_id = e.company_id
           and cu.user_id = s.user_id
           and cu.active = true
          where e.id = p_event_id
        )
      )
    )
  limit 1;
$$;

revoke all on function public.digi_valid_staff_v07(uuid,uuid,text[])
  from public, anon, authenticated;
grant execute on function public.digi_valid_staff_v07(uuid,uuid,text[])
  to service_role;

-- Explicitly allow the server role to use the v0.6 login function too.
grant execute on function public.digi_staff_login_v06(text,text,uuid)
  to service_role;

-- ---------------------------------------------------------------------------
-- v0.8: restore the proven guest photo-row registration path.
-- v0.5/r.zip successfully used anon INSERT + RLS after the signed Storage upload.
-- v0.6 revoked this and added /api/complete-upload, which is the regression we
-- are removing. Storage stays signed/private; only a pending metadata row may
-- be created for an event whose uploads are enabled.
-- ---------------------------------------------------------------------------

grant select on public.events, public.event_settings to anon, authenticated;
grant select, insert on public.photos to anon, authenticated;

alter table public.photos enable row level security;
drop policy if exists guest_insert_pending_photos on public.photos;
create policy guest_insert_pending_photos
on public.photos
for insert
to anon, authenticated
with check (
  status = 'pending'
  and event_id is not null
  and storage_path like ('events/' || event_id::text || '/pending/%')
  and exists (
    select 1
    from public.events e
    join public.event_settings s on s.event_id = e.id
    where e.id = photos.event_id
      and e.status in ('ready','live','post_event')
      and s.uploads_enabled = true
  )
);

-- Approved rows remain the only guest-readable photo metadata.
drop policy if exists public_read_approved_photos on public.photos;
create policy public_read_approved_photos
on public.photos
for select
to anon, authenticated
using (status = 'approved');

-- Keep the server's direct staff-session validation deterministic.
grant select on public.users, public.company_users, public.event_staff,
  public.staff_sessions, public.events, public.event_settings to service_role;
grant select, insert, update, delete on public.photos to service_role;
grant select, insert on public.photo_moderation_log, public.upload_ticket_log to service_role;

-- Refresh Data API metadata after the migration.
notify pgrst, 'reload schema';
select pg_notification_queue_usage();

-- ---------------------------------------------------------------------------
-- v0.8 timed events + event-scoped moderator code management.
-- ---------------------------------------------------------------------------

alter table public.events add column if not exists event_ends_at timestamptz;

-- Internal helper: a global company-admin token may manage any event that
-- belongs to the admin's company. This deliberately avoids the older RPC auth
-- chain and validates the token directly against the source tables.
create or replace function public.digi_admin_event_access_v08(
  p_token uuid,
  p_event_id uuid
)
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.staff_sessions s
    join public.users u
      on u.id = s.user_id
     and u.active = true
    join public.company_users cu
      on cu.user_id = s.user_id
     and cu.active = true
     and cu.role = 'company_admin'
    join public.events e
      on e.company_id = cu.company_id
     and e.id = p_event_id
    where s.token = p_token
      and s.role = 'company_admin'
      and s.expires_at > now()
  );
$$;

revoke all on function public.digi_admin_event_access_v08(uuid,uuid)
  from public, anon, authenticated;

-- Admin event update with an event-local end date/time. The text coming from
-- <input type="datetime-local"> is interpreted in the event's configured
-- timezone (Asia/Jerusalem by default) and stored as timestamptz.
create or replace function public.update_event_v08(
  p_token uuid,
  p_event_id uuid,
  p_name text,
  p_event_type text,
  p_event_date date,
  p_location text,
  p_status event_status,
  p_cover_image text default null,
  p_event_ends_local text default null
)
returns setof public.events
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.digi_admin_event_access_v08(p_token, p_event_id) then
    raise exception 'אין הרשאת מנהל';
  end if;

  if nullif(trim(coalesce(p_event_ends_local, '')), '') is not null then
    begin
      perform p_event_ends_local::timestamp;
    exception when others then
      raise exception 'זמן סיום האירוע אינו תקין';
    end;
  end if;

  return query
  update public.events
  set
    name = left(coalesce(nullif(trim(p_name), ''), name), 80),
    event_type = left(coalesce(nullif(trim(p_event_type), ''), event_type, 'אירוע'), 50),
    event_date = p_event_date,
    location = left(nullif(trim(coalesce(p_location, '')), ''), 160),
    status = p_status,
    cover_image = coalesce(nullif(trim(p_cover_image), ''), cover_image),
    event_ends_at = case
      when nullif(trim(coalesce(p_event_ends_local, '')), '') is null then null
      else p_event_ends_local::timestamp at time zone coalesce(timezone, 'Asia/Jerusalem')
    end,
    updated_at = now()
  where id = p_event_id
  returning *;
end;
$$;

grant execute on function public.update_event_v08(
  uuid,uuid,text,text,date,text,event_status,text,text
) to anon, authenticated;

-- The moderator approval code is truly per-event and can be replaced at any
-- time. Existing moderator sessions for that event are revoked immediately so
-- the old code cannot remain active through an already-open browser session.
create or replace function public.set_event_moderator_pin(
  p_token uuid,
  p_event_id uuid,
  p_pin text
)
returns void
language plpgsql
security definer
set search_path = public, extensions
as $$
begin
  if p_pin !~ '^\d{4}$' then
    raise exception 'הקוד חייב להכיל 4 ספרות';
  end if;

  if not public.digi_admin_event_access_v08(p_token, p_event_id) then
    raise exception 'אין הרשאת מנהל';
  end if;

  update public.event_staff
  set pin_hash = crypt(p_pin, gen_salt('bf'))
  where event_id = p_event_id
    and role = 'photo_moderator'
    and active = true;

  if not found then
    raise exception 'לא הוגדרה שושבינה לאירוע הזה';
  end if;

  delete from public.staff_sessions s
  using public.event_staff es
  where es.event_id = p_event_id
    and es.role = 'photo_moderator'
    and es.user_id = s.user_id
    and s.role = 'photo_moderator';
end;
$$;

grant execute on function public.set_event_moderator_pin(uuid,uuid,text)
  to anon, authenticated;

-- The database is the final gate for the timed upload window. Even if a guest
-- keeps an old page open, a pending row cannot be created after the deadline.
drop policy if exists guest_insert_pending_photos on public.photos;
create policy guest_insert_pending_photos
on public.photos
for insert
to anon, authenticated
with check (
  status = 'pending'
  and event_id is not null
  and storage_path like ('events/' || event_id::text || '/pending/%')
  and exists (
    select 1
    from public.events e
    join public.event_settings s on s.event_id = e.id
    where e.id = photos.event_id
      and e.status in ('ready','live','post_event')
      and s.uploads_enabled = true
      and (e.event_ends_at is null or now() < e.event_ends_at)
  )
);

notify pgrst, 'reload schema';

-- ---------------------------------------------------------------------------
-- Digi v0.8.1 — one private source of truth for each event's moderator PIN.
-- The PIN hash lives in a server-only table, never on the public event row.
-- Admin updates and moderator login both use this exact same record.
-- ---------------------------------------------------------------------------

create table if not exists public.event_moderator_secrets (
  event_id uuid primary key references public.events(id) on delete cascade,
  pin_hash text not null,
  updated_at timestamptz not null default now()
);

alter table public.event_moderator_secrets enable row level security;
revoke all on public.event_moderator_secrets from public, anon, authenticated;
grant select, insert, update, delete on public.event_moderator_secrets to service_role;

-- Preserve every existing event-specific PIN during upgrade. Never overwrite a
-- value already chosen in the new canonical table.
insert into public.event_moderator_secrets(event_id, pin_hash)
select e.id,
       (
         select es.pin_hash
         from public.event_staff es
         where es.event_id = e.id
           and es.role = 'photo_moderator'
           and es.active = true
           and es.pin_hash is not null
         order by es.created_at asc
         limit 1
       )
from public.events e
where exists (
  select 1
  from public.event_staff es
  where es.event_id = e.id
    and es.role = 'photo_moderator'
    and es.active = true
    and es.pin_hash is not null
)
on conflict (event_id) do nothing;

-- Demo fallback only when the demo event has never had any PIN at all.
insert into public.event_moderator_secrets(event_id, pin_hash)
select '00000000-0000-0000-0000-000000001001'::uuid,
       crypt('1234', gen_salt('bf'))
where exists (
  select 1 from public.events
  where id = '00000000-0000-0000-0000-000000001001'::uuid
)
on conflict (event_id) do nothing;

create or replace function public.digi_set_event_moderator_pin_v081(
  p_event_id uuid,
  p_pin text
)
returns void
language plpgsql
security definer
set search_path = public, extensions
as $$
begin
  if p_pin !~ '^\d{4}$' then
    raise exception 'הקוד חייב להכיל 4 ספרות';
  end if;

  if not exists (select 1 from public.events where id = p_event_id) then
    raise exception 'האירוע לא נמצא';
  end if;

  insert into public.event_moderator_secrets(event_id, pin_hash, updated_at)
  values (p_event_id, crypt(p_pin, gen_salt('bf')), now())
  on conflict (event_id) do update
  set pin_hash = excluded.pin_hash,
      updated_at = excluded.updated_at;

  -- Keep the legacy event_staff field synchronized only for backwards
  -- compatibility with older code; v0.8.1 login does not read it.
  update public.event_staff
  set pin_hash = crypt(p_pin, gen_salt('bf'))
  where event_id = p_event_id
    and role = 'photo_moderator'
    and active = true;

  -- A changed code invalidates every already-open moderator session for this
  -- event immediately. The new code is then the only way back in.
  delete from public.staff_sessions
  where event_id = p_event_id
    and role = 'photo_moderator';
end;
$$;

revoke all on function public.digi_set_event_moderator_pin_v081(uuid,text)
  from public, anon, authenticated;
grant execute on function public.digi_set_event_moderator_pin_v081(uuid,text)
  to service_role;

create or replace function public.digi_moderator_login_v081(
  p_event_id uuid,
  p_pin text
)
returns table (
  token uuid,
  user_id uuid,
  user_name text,
  role text
)
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_user_id uuid;
  v_user_name text;
  v_token uuid := gen_random_uuid();
  v_pin_hash text;
begin
  if p_pin !~ '^\d{4}$' then
    raise exception 'הקוד אינו נכון';
  end if;

  select s.pin_hash
    into v_pin_hash
  from public.event_moderator_secrets s
  where s.event_id = p_event_id
  limit 1;

  if v_pin_hash is null or crypt(p_pin, v_pin_hash) <> v_pin_hash then
    raise exception 'הקוד אינו נכון';
  end if;

  select u.id, u.name
    into v_user_id, v_user_name
  from public.event_staff es
  join public.users u on u.id = es.user_id
  where es.event_id = p_event_id
    and es.role = 'photo_moderator'
    and es.active = true
    and u.active = true
  order by es.created_at asc
  limit 1;

  if v_user_id is null then
    raise exception 'לא הוגדרה שושבינה לאירוע הזה';
  end if;

  delete from public.staff_sessions where expires_at < now();

  insert into public.staff_sessions(token,user_id,event_id,role,expires_at)
  values(v_token,v_user_id,p_event_id,'photo_moderator',now()+interval '12 hours');

  return query
  select v_token,v_user_id,v_user_name,'photo_moderator'::text;
end;
$$;

revoke all on function public.digi_moderator_login_v081(uuid,text)
  from public, anon, authenticated;
grant execute on function public.digi_moderator_login_v081(uuid,text)
  to service_role;

notify pgrst, 'reload schema';

-- ---------------------------------------------------------------------------
-- Digi v0.8.2 — canonical authorization for every staff surface.
-- ---------------------------------------------------------------------------

create or replace function public.digi_resolve_staff_session_v082(
  p_token uuid,
  p_event_id uuid,
  p_roles text[]
)
returns table (
  token uuid,
  user_id uuid,
  event_id uuid,
  role text
)
language sql
security definer
set search_path = public
as $$
  select s.token, s.user_id, s.event_id, s.role
  from public.staff_sessions s
  join public.users u
    on u.id = s.user_id
   and u.active = true
  where s.token = p_token
    and s.expires_at > now()
    and s.role = any(p_roles)
    and (
      (
        s.role = 'photo_moderator'
        and s.event_id = p_event_id
        and exists (
          select 1
          from public.event_staff es
          where es.event_id = p_event_id
            and es.user_id = s.user_id
            and es.role = 'photo_moderator'
            and es.active = true
        )
      )
      or
      (
        s.role = 'company_admin'
        and exists (
          select 1
          from public.events e
          join public.company_users cu
            on cu.company_id = e.company_id
           and cu.user_id = s.user_id
           and cu.active = true
           and cu.role = 'company_admin'
          where e.id = p_event_id
        )
      )
    )
  limit 1;
$$;

revoke all on function public.digi_resolve_staff_session_v082(uuid,uuid,text[])
  from public, anon, authenticated;
grant execute on function public.digi_resolve_staff_session_v082(uuid,uuid,text[])
  to service_role;

create or replace function public.digi_admin_set_event_moderator_pin_v082(
  p_token uuid,
  p_event_id uuid,
  p_pin text
)
returns void
language plpgsql
security definer
set search_path = public, extensions
as $$
begin
  if p_pin !~ '^\d{4}$' then
    raise exception 'הקוד חייב להכיל 4 ספרות';
  end if;

  if not exists (
    select 1
    from public.digi_resolve_staff_session_v082(
      p_token,
      p_event_id,
      array['company_admin']::text[]
    )
  ) then
    raise exception 'אין הרשאת מנהל';
  end if;

  insert into public.event_moderator_secrets(event_id, pin_hash, updated_at)
  values (p_event_id, crypt(p_pin, gen_salt('bf')), now())
  on conflict (event_id) do update
  set pin_hash = excluded.pin_hash,
      updated_at = excluded.updated_at;

  update public.event_staff
  set pin_hash = crypt(p_pin, gen_salt('bf'))
  where event_id = p_event_id
    and role = 'photo_moderator'
    and active = true;

  delete from public.staff_sessions
  where event_id = p_event_id
    and role = 'photo_moderator';
end;
$$;

revoke all on function public.digi_admin_set_event_moderator_pin_v082(uuid,uuid,text)
  from public, anon, authenticated;
grant execute on function public.digi_admin_set_event_moderator_pin_v082(uuid,uuid,text)
  to service_role;

notify pgrst, 'reload schema';

-- ---------------------------------------------------------------------------
-- Digi v0.8.3 — service-only PIN writer; authorization is centralized in the
-- Next server and validated directly against staff_sessions + memberships.
-- This function also repairs a missing moderator membership for migrated events.
-- ---------------------------------------------------------------------------
create or replace function public.digi_set_event_moderator_pin_v083(
  p_event_id uuid,
  p_pin text
)
returns void
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_event_name text;
  v_user_id uuid;
begin
  if p_pin !~ '^\d{4}$' then
    raise exception 'הקוד חייב להכיל 4 ספרות';
  end if;

  select e.name into v_event_name
  from public.events e
  where e.id = p_event_id;

  if v_event_name is null then
    raise exception 'האירוע לא נמצא';
  end if;

  select es.user_id into v_user_id
  from public.event_staff es
  join public.users u on u.id = es.user_id and u.active = true
  where es.event_id = p_event_id
    and es.role = 'photo_moderator'
    and es.active = true
  order by es.created_at asc
  limit 1;

  if v_user_id is null then
    v_user_id := gen_random_uuid();
    insert into public.users(id, name, phone, active)
    values(
      v_user_id,
      'שושבינות · ' || left(v_event_name, 60),
      'digi-event-' || p_event_id::text,
      true
    )
    on conflict (phone) do update set active = true
    returning id into v_user_id;

    insert into public.event_staff(event_id, user_id, role, active, pin_hash)
    values(p_event_id, v_user_id, 'photo_moderator', true, crypt(p_pin, gen_salt('bf')))
    on conflict (event_id, user_id) do update
      set active = true,
          pin_hash = excluded.pin_hash;
  else
    update public.event_staff
    set pin_hash = crypt(p_pin, gen_salt('bf'))
    where event_id = p_event_id
      and role = 'photo_moderator'
      and active = true;
  end if;

  insert into public.event_moderator_secrets(event_id, pin_hash, updated_at)
  values(p_event_id, crypt(p_pin, gen_salt('bf')), now())
  on conflict (event_id) do update
    set pin_hash = excluded.pin_hash,
        updated_at = excluded.updated_at;

  delete from public.staff_sessions
  where event_id = p_event_id
    and role = 'photo_moderator';
end;
$$;

revoke all on function public.digi_set_event_moderator_pin_v083(uuid,text)
  from public, anon, authenticated;
grant execute on function public.digi_set_event_moderator_pin_v083(uuid,text)
  to service_role;

notify pgrst, 'reload schema';
