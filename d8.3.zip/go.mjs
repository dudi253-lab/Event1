import fs from 'node:fs';
import process from 'node:process';
import pg from 'pg';

const { Client } = pg;

function askHidden(prompt) {
  return new Promise((resolve) => {
    const input = process.stdin;
    const output = process.stdout;
    let value = '';
    output.write(prompt);
    input.resume();
    input.setEncoding('utf8');
    if (input.isTTY && input.setRawMode) input.setRawMode(true);

    const onData = (char) => {
      if (char === '\u0003') process.exit(130);
      if (char === '\r' || char === '\n') {
        if (input.isTTY && input.setRawMode) input.setRawMode(false);
        input.pause();
        input.off('data', onData);
        output.write('\n');
        resolve(value);
        return;
      }
      if (char === '\u007f' || char === '\b') {
        value = value.slice(0, -1);
        return;
      }
      value += char;
    };

    input.on('data', onData);
  });
}

const password = await askHidden('DB password: ');
const sql = fs.readFileSync(new URL('./supabase/v0.8.sql', import.meta.url), 'utf8');

const client = new Client({
  host: 'aws-0-eu-central-2.pooler.supabase.com',
  port: 5432,
  database: 'postgres',
  user: 'postgres.fhlirqpqqvaudhighkww',
  password,
  ssl: { rejectUnauthorized: false },
});

try {
  await client.connect();
  await client.query(sql);
  const checks = await client.query(`
    select
      to_regclass('public.event_moderator_secrets') is not null as secrets_table,
      to_regprocedure('public.digi_set_event_moderator_pin_v083(uuid,text)') is not null as pin_writer,
      to_regprocedure('public.digi_moderator_login_v081(uuid,text)') is not null as moderator_login,
      to_regprocedure('public.company_admin_pin_login(text)') is not null as admin_login,
      to_regprocedure('public.list_company_events(uuid)') is not null as event_list,
      exists(select 1 from pg_policies where schemaname='public' and tablename='photos' and policyname='guest_insert_pending_photos') as guest_policy,
      exists(select 1 from information_schema.columns where table_schema='public' and table_name='events' and column_name='event_ends_at') as countdown_column
  `);
  const row = checks.rows[0] || {};
  const failed = Object.entries(row).filter(([, value]) => value !== true).map(([key]) => key);
  if (failed.length) throw new Error(`DB preflight failed: ${failed.join(', ')}`);
  console.log('✅ Digi v0.8.3 DB preflight passed (7/7)');
  console.log('✅ Digi v0.8.3 ready');
} catch (error) {
  console.error('❌ Digi setup failed');
  console.error(error?.message || error);
  process.exitCode = 1;
} finally {
  await client.end().catch(() => {});
}
