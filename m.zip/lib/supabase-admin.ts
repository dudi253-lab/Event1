import { createClient } from '@supabase/supabase-js';

function serverConfig() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL?.trim() || '';
  const serviceKey =
    process.env.SUPABASE_SECRET_KEY?.trim() ||
    process.env.SUPABASE_SERVICE_ROLE_KEY?.trim() ||
    '';

  return { url, serviceKey };
}

export function getSupabaseAdmin() {
  const { url, serviceKey } = serverConfig();

  if (!url || !serviceKey) {
    throw new Error('Digi server configuration is incomplete. Missing Supabase URL or server secret.');
  }

  return createClient(url, serviceKey, {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
  });
}

export function getServerConfigHealth() {
  const { url, serviceKey } = serverConfig();
  return {
    urlConfigured: Boolean(url),
    secretConfigured: Boolean(serviceKey),
    secretKind: serviceKey.startsWith('sb_secret_')
      ? 'secret'
      : serviceKey.startsWith('eyJ')
        ? 'legacy-service-role'
        : serviceKey
          ? 'unknown'
          : 'missing',
  };
}

export async function validStaffToken(
  token: string,
  eventId: string,
  allowedRoles: Array<'company_admin' | 'photo_moderator'>,
) {
  const admin = getSupabaseAdmin();

  // Keep authorization in PostgreSQL, where the session is created.
  // This avoids client/server mismatches around RLS, timestamps or UUID handling.
  const { data, error } = await admin.rpc('valid_staff_session', {
    p_token: token,
    p_event_id: eventId,
    p_roles: allowedRoles,
  });

  if (error) {
    console.error('valid_staff_session', error);
    return false;
  }

  return data === true;
}
