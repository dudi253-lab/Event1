import fs from 'node:fs';
import process from 'node:process';
import pg from 'pg';
import { createClient } from '@supabase/supabase-js';

const { Client } = pg;

function askHidden(prompt) {
  return new Promise((resolve) => {
    const input = process.stdin;
    const output = process.stdout;
    let value = '';
    output.write(prompt);
    input.resume();
    input.setEncoding('utf8');
    if (input.isTTY && input.setRawMode) input.setRawMode(true);

    const onData = (char) => {
      if (char === '\u0003') process.exit(130);
      if (char === '\r' || char === '\n') {
        if (input.isTTY && input.setRawMode) input.setRawMode(false);
        input.pause();
        input.off('data', onData);
        output.write('\n');
        resolve(value);
        return;
      }
      if (char === '\u007f' || char === '\b') {
        value = value.slice(0, -1);
        return;
      }
      value += char;
    };

    input.on('data', onData);
  });
}

function readEnvFile(path) {
  if (!fs.existsSync(path)) return {};
  const out = {};
  for (const raw of fs.readFileSync(path, 'utf8').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const idx = line.indexOf('=');
    if (idx < 1) continue;
    const key = line.slice(0, idx).trim();
    let value = line.slice(idx + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    out[key] = value;
  }
  return out;
}

const password = await askHidden('DB password: ');
const sql = fs.readFileSync(new URL('./supabase/v0.8.sql', import.meta.url), 'utf8');
const env = { ...readEnvFile('.env.local'), ...process.env };

const client = new Client({
  host: 'aws-0-eu-central-2.pooler.supabase.com',
  port: 5432,
  database: 'postgres',
  user: 'postgres.fhlirqpqqvaudhighkww',
  password,
  ssl: { rejectUnauthorized: false },
});

let testEventId = null;
let testUserId = null;

try {
  await client.connect();
  await client.query(sql);

  const checks = await client.query(`
    select
      to_regclass('public.event_moderator_secrets') is not null as secrets_table,
      to_regprocedure('public.digi_set_event_moderator_pin_v084(uuid,text)') is not null as pin_writer,
      to_regprocedure('public.digi_moderator_login_v084(uuid,text)') is not null as moderator_login,
      to_regprocedure('public.company_admin_pin_login(text)') is not null as admin_login,
      to_regprocedure('public.list_company_events(uuid)') is not null as event_list,
      exists(select 1 from pg_policies where schemaname='public' and tablename='photos' and policyname='guest_insert_pending_photos') as guest_policy,
      exists(select 1 from information_schema.columns where table_schema='public' and table_name='events' and column_name='event_ends_at') as countdown_column
  `);

  const row = checks.rows[0] || {};
  const failed = Object.entries(row).filter(([, value]) => value !== true).map(([key]) => key);
  if (failed.length) throw new Error(`DB preflight failed: ${failed.join(', ')}`);

  const companyResult = await client.query(`
    select company_id
    from public.events
    where id = '00000000-0000-0000-0000-000000001001'::uuid
    limit 1
  `);
  const companyId = companyResult.rows[0]?.company_id;
  if (!companyId) throw new Error('Demo company not found for E2E test.');

  // Create a disposable event/user so the test never changes the user's real PIN.
  const eventResult = await client.query(`
    insert into public.events(company_id,name,event_type,status,slug)
    values($1,'Digi PIN self-test','test','draft','digi-pin-test-' || replace(gen_random_uuid()::text,'-',''))
    returning id
  `, [companyId]);
  testEventId = eventResult.rows[0].id;

  const userResult = await client.query(`
    insert into public.users(name,phone,active)
    values('Digi PIN self-test','digi-selftest-' || replace(gen_random_uuid()::text,'-',''),true)
    returning id
  `);
  testUserId = userResult.rows[0].id;

  await client.query(`
    insert into public.event_staff(event_id,user_id,role,active)
    values($1,$2,'photo_moderator',true)
  `, [testEventId, testUserId]);

  const url = String(env.NEXT_PUBLIC_SUPABASE_URL || '').trim();
  const serviceKey = String(env.SUPABASE_SECRET_KEY || env.SUPABASE_SERVICE_ROLE_KEY || '').trim();
  if (!url || !serviceKey) throw new Error('Missing Supabase server env for RPC E2E test.');

  const supabase = createClient(url, serviceKey, {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
  });

  const { error: setError } = await supabase.rpc('digi_set_event_moderator_pin_v084', {
    p_event_id: testEventId,
    p_pin: '8642',
  });
  if (setError) throw new Error(`PIN writer RPC failed: ${setError.message}`);

  const { data: loginData, error: loginError } = await supabase.rpc('digi_moderator_login_v084', {
    p_event_id: testEventId,
    p_pin: '8642',
  });
  if (loginError) throw new Error(`Moderator login RPC failed: ${loginError.message}`);

  const loginRow = Array.isArray(loginData) ? loginData[0] : loginData;
  if (!loginRow?.token || loginRow?.role !== 'photo_moderator') {
    throw new Error('Moderator login RPC returned no valid session.');
  }

  const sessionCheck = await client.query(`
    select exists(
      select 1
      from public.staff_sessions
      where token=$1::uuid
        and event_id=$2::uuid
        and role='photo_moderator'
        and expires_at > now()
    ) as ok
  `, [loginRow.token, testEventId]);

  if (!sessionCheck.rows[0]?.ok) throw new Error('Moderator session was not persisted.');

  console.log('✅ Digi v0.8.4 DB preflight passed (7/7)');
  console.log('✅ Digi v0.8.4 moderator PIN E2E passed');
  console.log('✅ Digi v0.8.4 ready');
} catch (error) {
  console.error('❌ Digi setup failed');
  console.error(error?.message || error);
  process.exitCode = 1;
} finally {
  if (testEventId) {
    await client.query('delete from public.events where id=$1', [testEventId]).catch(() => {});
  }
  if (testUserId) {
    await client.query('delete from public.users where id=$1', [testUserId]).catch(() => {});
  }
  await client.end().catch(() => {});
}
