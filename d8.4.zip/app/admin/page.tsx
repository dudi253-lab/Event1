'use client';

import Link from 'next/link';
import { ChangeEvent, FormEvent, useEffect, useMemo, useState } from 'react';
import { Logo } from '@/components/Logo';
import { StaffLogin } from '@/components/StaffLogin';
import { EventCountdown } from '@/components/EventCountdown';
import {
  AdminSession,
  companyAdminLogin,
  createCompanyEvent,
  deletePhotoPermanent,
  EventHealth,
  EventRow,
  EventStats,
  EventStatus,
  eventPublicKey,
  getEventHealth,
  getEventStats,
  listCompanyEvents,
  listStaffPhotos,
  moderatePhoto,
  PhotoRow,
  photoSrc,
  setEventModeratorPin,
  updateEvent,
  uploadEventCover,
} from '@/lib/event-api';

type Tab = 'events' | 'new' | 'dashboard' | 'design' | 'access' | 'media';

const statusLabels: Record<EventStatus, string> = {
  draft: 'טיוטה',
  ready: 'מוכן',
  live: 'באוויר',
  post_event: 'אחרי האירוע',
  archived: 'ארכיון',
};

function bytesLabel(bytes = 0) {
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(bytes > 100 * 1024 * 1024 ? 0 : 1)} MB`;
}

function eventEndInput(value?: string | null, timeZone = 'Asia/Jerusalem') {
  if (!value) return '';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '';

  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(date);
  const part = (type: Intl.DateTimeFormatPartTypes) => parts.find((item) => item.type === type)?.value || '';
  return `${part('year')}-${part('month')}-${part('day')}T${part('hour')}:${part('minute')}`;
}

const photoStatusLabels: Record<PhotoRow['status'], string> = {
  pending: 'ממתינה',
  approved: 'פורסמה',
  private: 'פרטית',
  rejected: 'נדחתה',
};

export default function AdminPage() {
  const [session, setSession] = useState<AdminSession | null>(null);
  const [restoring, setRestoring] = useState(true);
  const [events, setEvents] = useState<EventRow[]>([]);
  const [event, setEvent] = useState<EventRow | null>(null);
  const [activeTab, setActiveTab] = useState<Tab>('events');
  const [stats, setStats] = useState<EventStats | null>(null);
  const [health, setHealth] = useState<EventHealth | null>(null);
  const [media, setMedia] = useState<PhotoRow[]>([]);

  const [name, setName] = useState('');
  const [eventType, setEventType] = useState('');
  const [eventDate, setEventDate] = useState('');
  const [eventEndsLocal, setEventEndsLocal] = useState('');
  const [location, setLocation] = useState('');
  const [status, setStatus] = useState<EventStatus>('draft');
  const [coverPreview, setCoverPreview] = useState('');
  const [coverFile, setCoverFile] = useState<File | null>(null);
  const [moderatorPin, setModeratorPin] = useState('');

  const [newName, setNewName] = useState('');
  const [newType, setNewType] = useState('חתונה');
  const [newDate, setNewDate] = useState('');
  const [newEndsLocal, setNewEndsLocal] = useState('');
  const [newPin, setNewPin] = useState('');
  const [mediaFilter, setMediaFilter] = useState<PhotoRow['status'] | 'all'>('pending');

  const [busy, setBusy] = useState(false);
  const [saved, setSaved] = useState(false);
  const [copied, setCopied] = useState('');
  const [error, setError] = useState('');

  const applyEventToForm = (next: EventRow) => {
    setName(next.name);
    setEventType(next.event_type || '');
    setEventDate(next.event_date || '');
    setEventEndsLocal(eventEndInput(next.event_ends_at, next.timezone || 'Asia/Jerusalem'));
    setLocation(next.location || '');
    setStatus(next.status);
    setCoverPreview(next.cover_image || '');
    setCoverFile(null);
  };

  const selectEvent = (next: EventRow, tab: Tab = 'dashboard') => {
    setEvent(next);
    applyEventToForm(next);
    setStats(null);
    setHealth(null);
    setMedia([]);
    setMediaFilter('pending');
    setError('');
    setActiveTab(tab);
  };

  const refreshEvents = async (nextSession = session) => {
    if (!nextSession) return [];
    const rows = await listCompanyEvents(nextSession.token);
    setEvents(rows);
    if (event) {
      const refreshed = rows.find((row) => row.id === event.id);
      if (refreshed) {
        setEvent(refreshed);
        applyEventToForm(refreshed);
      }
    }
    return rows;
  };

  const refreshSelected = async (
    nextSession = session,
    nextEvent = event,
    includeMedia = activeTab === 'media',
  ) => {
    if (!nextSession || !nextEvent) return;
    const tasks: Promise<unknown>[] = [
      getEventStats(nextSession.token, nextEvent.id).then(setStats),
      getEventHealth(nextSession.token, nextEvent.id).then(setHealth),
    ];
    if (includeMedia) {
      tasks.push(listStaffPhotos(nextSession.token, nextEvent.id, 'all', 0, 60).then((r) => setMedia(r.photos)));
    }
    await Promise.allSettled(tasks);
  };

  useEffect(() => {
    const raw = window.sessionStorage.getItem('digi-admin-session');
    if (!raw) {
      setRestoring(false);
      return;
    }

    try {
      const savedSession = JSON.parse(raw) as AdminSession;
      void listCompanyEvents(savedSession.token)
        .then((rows) => {
          setSession(savedSession);
          setEvents(rows);
          if (rows.length === 1) selectEvent(rows[0], 'dashboard');
        })
        .catch(() => window.sessionStorage.removeItem('digi-admin-session'))
        .finally(() => setRestoring(false));
    } catch {
      window.sessionStorage.removeItem('digi-admin-session');
      setRestoring(false);
    }
  }, []);

  useEffect(() => {
    if (session && event) void refreshSelected(session, event, activeTab === 'media');
  }, [session?.token, event?.id, activeTab]);

  const login = async (pin: string) => {
    const nextSession = await companyAdminLogin(pin);
    setSession(nextSession);
    window.sessionStorage.setItem('digi-admin-session', JSON.stringify(nextSession));
    const rows = await refreshEvents(nextSession);
    if (rows.length === 1) selectEvent(rows[0], 'dashboard');
    else setActiveTab('events');
  };

  const logout = () => {
    window.sessionStorage.removeItem('digi-admin-session');
    setSession(null);
    setEvent(null);
    setEvents([]);
    setActiveTab('events');
  };

  const createEvent = async (e: FormEvent) => {
    e.preventDefault();
    if (!session) return;
    setBusy(true);
    setError('');
    try {
      const created = await createCompanyEvent(session.token, {
        name: newName.trim(),
        eventType: newType.trim() || 'אירוע',
        eventDate: newDate || undefined,
        moderatorPin: newPin,
        eventEndsLocal: newEndsLocal || null,
      });
      const rows = await refreshEvents(session);
      const next = rows.find((row) => row.id === created.id) || created;
      setNewName('');
      setNewType('חתונה');
      setNewDate('');
      setNewEndsLocal('');
      setNewPin('');
      selectEvent(next, 'dashboard');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'יצירת האירוע נכשלה.');
    } finally {
      setBusy(false);
    }
  };

  const selectCover = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setCoverFile(file);
    if (file) setCoverPreview(URL.createObjectURL(file));
  };

  const saveEvent = async (e: FormEvent) => {
    e.preventDefault();
    if (!session || !event) return;
    setBusy(true);
    setError('');
    try {
      let coverImage = event.cover_image;
      if (coverFile) coverImage = await uploadEventCover(session.token, event.id, coverFile);

      const updated = await updateEvent(session.token, event.id, {
        name: name.trim() || event.name,
        eventType: eventType.trim() || 'אירוע',
        eventDate: eventDate || null,
        location,
        status,
        coverImage,
        eventEndsLocal: eventEndsLocal || null,
      });

      setEvents((items) => items.map((item) => item.id === updated.id ? updated : item));
      setEvent(updated);
      applyEventToForm(updated);
      setSaved(true);
      window.setTimeout(() => setSaved(false), 2200);
      await refreshSelected(session, updated, activeTab === 'media');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'השמירה נכשלה.');
    } finally {
      setBusy(false);
    }
  };

  const saveModeratorPin = async () => {
    if (!session || !event) return;
    setBusy(true);
    setError('');
    try {
      await setEventModeratorPin(session.token, event.id, moderatorPin);
      setModeratorPin('');
      setSaved(true);
      window.setTimeout(() => setSaved(false), 2200);
      await refreshSelected();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'עדכון הקוד נכשל.');
    } finally {
      setBusy(false);
    }
  };

  const adminModerate = async (photo: PhotoRow, nextStatus: PhotoRow['status']) => {
    if (!session || !event || busy || photo.status === nextStatus) return;
    setBusy(true);
    setError('');
    try {
      await moderatePhoto(session.token, photo.id, nextStatus, photo.status);
      setMedia((items) => items.map((item) =>
        item.id === photo.id ? { ...item, status: nextStatus } : item,
      ));
      await refreshSelected(session, event, false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'אישור התמונה נכשל.');
      await refreshSelected(session, event, true);
    } finally {
      setBusy(false);
    }
  };

  const removePhoto = async (photo: PhotoRow) => {
    if (!session || !event || busy) return;
    const confirmed = window.confirm('למחוק את התמונה לצמיתות? הפעולה תסיר אותה גם מהאחסון ולא ניתן לבטל.');
    if (!confirmed) return;

    setBusy(true);
    try {
      await deletePhotoPermanent(session.token, event.id, photo.id);
      setMedia((items) => items.filter((item) => item.id !== photo.id));
      await refreshSelected(session, event, false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'המחיקה נכשלה.');
    } finally {
      setBusy(false);
    }
  };

  const publicUrl = useMemo(() => {
    if (!event || typeof window === 'undefined') return '';
    return `${window.location.origin}/e/${eventPublicKey(event)}`;
  }, [event]);

  const moderatorUrl = useMemo(() => {
    if (!event || typeof window === 'undefined') return '';
    return `${window.location.origin}/e/${eventPublicKey(event)}/moderator`;
  }, [event]);

  const copy = async (value: string, label: string) => {
    await navigator.clipboard.writeText(value);
    setCopied(label);
    window.setTimeout(() => setCopied(''), 1800);
  };

  const share = async () => {
    if (!publicUrl) return;
    if (navigator.share) {
      await navigator.share({ title: event?.name || 'Digi', text: 'האלבום המשותף שלנו', url: publicUrl });
    } else {
      await copy(publicUrl, 'קישור');
    }
  };

  if (restoring) {
    return <main className="loginPage"><div className="loginCard"><Logo /><p>פותח את Digi…</p></div></main>;
  }

  if (!session) {
    return (
      <StaffLogin
        roleLabel="Digi · ניהול"
        title="פאנל מנהלים"
        subtitle="כניסה אחת לכל האירועים של Digi."
        backHref="/"
        onSubmit={login}
      />
    );
  }

  const qrSrc = publicUrl
    ? `https://quickchart.io/qr?text=${encodeURIComponent(publicUrl)}&size=420&margin=2&dark=111111&light=ffffff`
    : '';

  const healthChecks = event && health ? [
    { label: 'קישור ציבורי קבוע', ok: health.public_link_ready },
    { label: 'קוד שושבינות', ok: health.moderator_ready },
    { label: 'הגדרות אלבום', ok: health.settings_ready },
    { label: 'תמונת קאבר', ok: health.cover_ready },
    { label: 'זמן סיום הוגדר', ok: Boolean(event.event_ends_at) },
    { label: 'סטטוס פעיל', ok: ['ready', 'live', 'post_event'].includes(event.status) },
  ] : [];
  const ready = healthChecks.length > 0 && healthChecks.every((item) => item.ok);

  return (
    <main className="adminPage">
      <aside className="adminSidebar">
        <Logo />
        <nav>
          <button className={activeTab === 'events' ? 'active' : ''} onClick={() => setActiveTab('events')}>אירועים</button>
          <button className={activeTab === 'new' ? 'active' : ''} onClick={() => setActiveTab('new')}>＋ חדש</button>
          {event && <button className={activeTab === 'dashboard' ? 'active' : ''} onClick={() => setActiveTab('dashboard')}>סקירה</button>}
          {event && <button className={activeTab === 'design' ? 'active' : ''} onClick={() => setActiveTab('design')}>אירוע</button>}
          {event && <button className={activeTab === 'media' ? 'active' : ''} onClick={() => setActiveTab('media')}>תמונות</button>}
          {event && <button className={activeTab === 'access' ? 'active' : ''} onClick={() => setActiveTab('access')}>QR / NFC</button>}
        </nav>
        <button className="adminLogout" onClick={logout}>יציאה</button>
      </aside>

      <section className="adminMain">
        <header className="adminTopbar">
          <div>
            <span>Digi · v0.8.4</span>
            <h1>
              {activeTab === 'events' ? 'כל האירועים'
                : activeTab === 'new' ? 'אירוע חדש'
                : event?.name || 'Digi'}
            </h1>
            {event && !['events', 'new'].includes(activeTab) && (
              <EventCountdown
                endAt={event.event_ends_at}
                timeZone={event.timezone}
                variant="admin"
              />
            )}
          </div>
          <div className="adminAvatar">D</div>
        </header>

        {error && <div className="inlineError adminError">{error}</div>}

        {activeTab === 'events' && (
          <section className="adminPanel">
            <div className="accessIntro">
              <span className="adminEyebrow">Multi‑Event</span>
              <h2>האירועים של Digi</h2>
              <p>כל אירוע מבודד עם אלבום, קישור, QR וכניסת שושבינות משלו.</p>
            </div>

            <div className="eventList">
              {events.map((item) => {
                const key = eventPublicKey(item);
                return (
                  <article key={item.id} className="eventListCard">
                    {item.cover_image
                      ? <img src={item.cover_image} alt="" />
                      : <div className="eventCardPlaceholder">D</div>}
                    <div>
                      <div className="eventCardMeta">
                        <span>{item.event_type || 'אירוע'}</span>
                        <b data-status={item.status}>{statusLabels[item.status]}</b>
                      </div>
                      <h3>{item.name}</h3>
                      <p>{item.event_date || 'ללא תאריך'} · {key}</p>
                      <div className="adminInlineActions">
                        <button onClick={() => selectEvent(item)}>ניהול</button>
                        <Link className="secondaryAdminButton" href={`/e/${key}`} target="_blank">אלבום</Link>
                        <Link className="secondaryAdminButton" href={`/e/${key}/moderator`} target="_blank">שושבינות</Link>
                      </div>
                    </div>
                  </article>
                );
              })}

              {!events.length && (
                <div className="albumEmpty">
                  <span>＋</span>
                  <h3>עוד אין אירועים</h3>
                  <p>צרו את האירוע הראשון של Digi.</p>
                </div>
              )}
            </div>
          </section>
        )}

        {activeTab === 'new' && (
          <section className="adminPanel compactPanel">
            <span className="adminEyebrow">אירוע חדש</span>
            <h2>קישור ו־QR נוצרים אוטומטית</h2>
            <form className="adminForm" onSubmit={createEvent}>
              <label>שם האירוע<input value={newName} onChange={(e) => setNewName(e.target.value)} maxLength={80} required /></label>
              <label>סוג האירוע<input value={newType} onChange={(e) => setNewType(e.target.value)} maxLength={50} /></label>
              <label>תאריך<input type="date" value={newDate} onChange={(e) => setNewDate(e.target.value)} /></label>
              <label>סיום האירוע / סגירת העלאות<input type="datetime-local" value={newEndsLocal} onChange={(e) => setNewEndsLocal(e.target.value)} required /></label>
              <label>קוד שושבינות לאישור תמונות<input inputMode="numeric" type="password" maxLength={4} value={newPin} onChange={(e) => setNewPin(e.target.value.replace(/\D/g, '').slice(0, 4))} required /></label>
              <button className="adminPrimary" disabled={busy || newPin.length !== 4 || !newEndsLocal}>{busy ? 'יוצר…' : 'יצירת אירוע'}</button>
            </form>
          </section>
        )}

        {activeTab === 'dashboard' && event && (
          <>
            <div className="metricGrid">
              <Metric label="סה״כ" value={stats?.total || 0} />
              <Metric label="ממתינות" value={stats?.pending || 0} />
              <Metric label="פורסמו" value={stats?.approved || 0} />
              <Metric label="אחסון" value={bytesLabel(stats?.storage_bytes || 0)} />
            </div>

            <section className={`eventHealth ${ready ? 'ready' : ''}`}>
              <div>
                <span>Event Health</span>
                <h2>{ready ? 'מוכן לאירוע ✓' : 'יש עוד כמה דברים לסגור'}</h2>
              </div>
              <div className="healthChecks">
                {healthChecks.map((item) => (
                  <span key={item.label} className={item.ok ? 'ok' : ''}>
                    {item.ok ? '✓' : '○'} {item.label}
                  </span>
                ))}
              </div>
            </section>

            <section className="adminPanel eventOverview">
              <div>
                <span className="adminEyebrow">{event.event_type || 'אירוע'} · {statusLabels[event.status]}</span>
                <h2>{event.name}</h2>
                <p>{event.event_date || 'ללא תאריך'}{event.location ? ` · ${event.location}` : ''}</p>
                <div className="adminInlineActions">
                  <button onClick={() => setActiveTab('design')}>עריכת האירוע</button>
                  <button className="secondaryAdminButton" onClick={() => setActiveTab('access')}>QR / NFC</button>
                  <button className="secondaryAdminButton" onClick={() => setActiveTab('media')}>ניהול תמונות</button>
                </div>
              </div>
              {event.cover_image && <img src={event.cover_image} alt="" />}
            </section>
          </>
        )}

        {activeTab === 'design' && event && (
          <section className="designWorkspace">
            <form className="designForm adminPanel" onSubmit={saveEvent}>
              <span className="adminEyebrow">פרטי האירוע</span>
              <h2>כל שינוי נשאר באותו קישור</h2>

              <label>שם האירוע<input value={name} onChange={(e) => setName(e.target.value)} maxLength={80} /></label>
              <label>סוג האירוע<input value={eventType} onChange={(e) => setEventType(e.target.value)} maxLength={50} /></label>
              <label>תאריך<input type="date" value={eventDate} onChange={(e) => setEventDate(e.target.value)} /></label>
              <label>סיום האירוע / סגירת העלאות<input type="datetime-local" value={eventEndsLocal} onChange={(e) => setEventEndsLocal(e.target.value)} /></label>
              <label>מיקום<input value={location} onChange={(e) => setLocation(e.target.value)} maxLength={160} placeholder="למשל: חוות רונית" /></label>
              <label>סטטוס
                <select value={status} onChange={(e) => setStatus(e.target.value as EventStatus)}>
                  <option value="draft">טיוטה — אין העלאות</option>
                  <option value="ready">מוכן — העלאות פתוחות</option>
                  <option value="live">באוויר</option>
                  <option value="post_event">אחרי האירוע</option>
                  <option value="archived">ארכיון</option>
                </select>
              </label>

              <label className="coverUploadLabel">
                תמונת קאבר
                <span>בחירת תמונה מהאייפון</span>
                <input type="file" accept="image/*,.heic,.heif" onChange={selectCover} />
              </label>

              <button className="adminPrimary" type="submit" disabled={busy}>{busy ? 'שומר…' : 'שמירת שינויים'}</button>
              {saved && <div className="saveNotice">✓ נשמר</div>}

              <div className="pinAdminBox">
                <span>קוד שושבינות לאישור תמונות · לאירוע הזה בלבד</span>
                <small>אפשר להחליף את הקוד בכל רגע. שינוי הקוד מנתק אוטומטית כניסות ישנות.</small>
                <div>
                  <input inputMode="numeric" type="password" maxLength={4} value={moderatorPin} onChange={(e) => setModeratorPin(e.target.value.replace(/\D/g, '').slice(0, 4))} placeholder="••••" />
                  <button type="button" onClick={() => void saveModeratorPin()} disabled={busy || moderatorPin.length !== 4}>שמירת קוד חדש</button>
                </div>
              </div>
            </form>

            <div className="coverPreviewCard adminPanel">
              <span>Story 9:16</span>
              <div
                className="coverPreviewStory"
                style={coverPreview ? { backgroundImage: `linear-gradient(180deg,rgba(0,0,0,.06),rgba(0,0,0,.7)),url("${coverPreview}")` } : undefined}
              >
                <small>Digi</small>
                <div>
                  <em>{eventDate || 'תאריך האירוע'}</em>
                  <strong>{name || 'שם האירוע'}</strong>
                  <span>{eventType || 'אירוע'}</span>
                </div>
              </div>
            </div>
          </section>
        )}

        {activeTab === 'media' && event && (
          <section className="adminPanel">
            <div className="accessIntro">
              <span className="adminEyebrow">אישור וניהול תמונות</span>
              <h2>כל אירוע מאושר בנפרד</h2>
              <p>כאן אפשר לאשר, לדחות, להעביר לפרטי או למחוק — בלי להיכנס למסך השושבינות.</p>
            </div>

            <div className="adminMediaFilters">
              {([
                ['pending', `ממתינות ${media.filter((p) => p.status === 'pending').length}`],
                ['approved', 'פורסמו'],
                ['private', 'פרטיות'],
                ['rejected', 'נדחו'],
                ['all', 'הכול'],
              ] as const).map(([value, label]) => (
                <button
                  key={value}
                  className={mediaFilter === value ? 'active' : ''}
                  onClick={() => setMediaFilter(value)}
                >
                  {label}
                </button>
              ))}
            </div>

            <div className="adminMediaGrid adminApprovalGrid">
              {media
                .filter((photo) => mediaFilter === 'all' || photo.status === mediaFilter)
                .map((photo) => (
                  <article key={photo.id}>
                    {photoSrc(photo) && <img src={photoSrc(photo)} alt={photo.original_filename || 'תמונה'} />}
                    <div className="adminPhotoMeta">
                      <span data-status={photo.status}>{photoStatusLabels[photo.status]}</span>
                      <div className="adminPhotoActions">
                        {photo.status === 'pending' && (
                          <>
                            <button className="approvePhoto" onClick={() => void adminModerate(photo, 'approved')} disabled={busy}>✓ אישור</button>
                            <button onClick={() => void adminModerate(photo, 'private')} disabled={busy}>פרטי</button>
                            <button className="rejectPhoto" onClick={() => void adminModerate(photo, 'rejected')} disabled={busy}>דחייה</button>
                          </>
                        )}
                        {photo.status === 'approved' && (
                          <button onClick={() => void adminModerate(photo, 'private')} disabled={busy}>הסרה מהאלבום</button>
                        )}
                        {(photo.status === 'private' || photo.status === 'rejected') && (
                          <button onClick={() => void adminModerate(photo, 'pending')} disabled={busy}>החזרה לממתינות</button>
                        )}
                        <button className="deletePhoto" onClick={() => void removePhoto(photo)} disabled={busy}>מחיקה</button>
                      </div>
                    </div>
                  </article>
                ))}
            </div>
            {!media.filter((photo) => mediaFilter === 'all' || photo.status === mediaFilter).length && (
              <div className="publishedEmpty">אין תמונות בסטטוס הזה באירוע.</div>
            )}
          </section>
        )}

        {activeTab === 'access' && event && (
          <section className="accessWorkspace">
            <div className="accessIntro adminPanel">
              <span className="adminEyebrow">קישורים קבועים</span>
              <h2>לכל אירוע כתובת משלו</h2>
              <p>אפשר לשנות שם, קאבר ותאריך בלי לשבור את ה־QR שכבר הודפס.</p>
            </div>

            <div className="accessGrid">
              <article className="qrCard adminPanel">
                <div className="qrFrame">{qrSrc && <img src={qrSrc} alt="QR לאלבום" />}</div>
                <h3>QR לאלבום</h3>
                <p>מוביל רק לאירוע: {event.name}</p>
                <button onClick={() => void share()}>שיתוף QR / קישור</button>
              </article>

              <article className="linkCard adminPanel">
                <span>קישור אורחים</span>
                <div className="urlBox">{publicUrl}</div>
                <button onClick={() => void copy(publicUrl, 'public')}>{copied === 'public' ? '✓ הועתק' : 'העתקת קישור'}</button>

                <span>קישור שושבינות — רק האירוע הזה</span>
                <div className="urlBox">{moderatorUrl}</div>
                <button onClick={() => void copy(moderatorUrl, 'moderator')}>{copied === 'moderator' ? '✓ הועתק' : 'העתקת קישור שושבינות'}</button>

                <div className="accessPinBox">
                  <span>קוד שושבינות לאישור תמונות</span>
                  <small>בחרו כל 4 ספרות שתרצו. הקוד שייך רק לאירוע הזה.</small>
                  <div>
                    <input inputMode="numeric" type="password" maxLength={4} value={moderatorPin} onChange={(e) => setModeratorPin(e.target.value.replace(/\D/g, '').slice(0, 4))} placeholder="••••" />
                    <button onClick={() => void saveModeratorPin()} disabled={busy || moderatorPin.length !== 4}>שמירת קוד</button>
                  </div>
                </div>

                <div className="nfcBlock">
                  <span>NFC</span>
                  <p>ל־NFC צורבים את אותו קישור ציבורי בדיוק.</p>
                  <button className="secondaryAdminButton" onClick={() => void copy(publicUrl, 'nfc')}>{copied === 'nfc' ? '✓ הועתק' : 'העתקת קישור ל־NFC'}</button>
                </div>
              </article>
            </div>
          </section>
        )}
      </section>
    </main>
  );
}

function Metric({ label, value }: { label: string; value: number | string }) {
  return (
    <div className="metricCard">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}
