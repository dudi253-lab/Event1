import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase-admin';

type LoginRow = {
  token?: string;
  user_id?: string;
  user_name?: string;
  role?: string;
};

function firstRow(data: unknown): LoginRow | null {
  if (Array.isArray(data)) return (data[0] || null) as LoginRow | null;
  return (data || null) as LoginRow | null;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const eventId = String(body?.eventId || '');
    const pin = String(body?.pin || '').replace(/\D/g, '').slice(0, 4);
    const role = body?.role === 'company_admin' ? 'company_admin' : 'photo_moderator';

    if (!eventId || pin.length !== 4) {
      return NextResponse.json({ error: 'הקוד אינו נכון.' }, { status: 400 });
    }

    const admin = getSupabaseAdmin();

    if (role === 'photo_moderator') {
      // v0.8.4 is the canonical path. The older calls are only migration
      // fallbacks so an already-upgraded event can never be locked out by
      // PostgREST cache timing or a legacy PIN copy.
      const attempts = [
        () => admin.rpc('digi_moderator_login_v084', { p_event_id: eventId, p_pin: pin }),
        () => admin.rpc('digi_moderator_login_v081', { p_event_id: eventId, p_pin: pin }),
        () => admin.rpc('digi_staff_login_v06', {
          p_pin: pin,
          p_role: 'photo_moderator',
          p_event_id: eventId,
        }),
      ];

      let lastError: unknown = null;

      for (const attempt of attempts) {
        const { data, error } = await attempt();
        const row = firstRow(data);

        if (!error && row?.token) {
          return NextResponse.json({
            token: row.token,
            user_id: row.user_id,
            user_name: row.user_name,
            role: row.role || 'photo_moderator',
          });
        }

        lastError = error || new Error('Moderator login returned no session.');
      }

      console.error('moderator login failed after all paths', lastError);
      return NextResponse.json({ error: 'הקוד אינו נכון.' }, { status: 401 });
    }

    const { data, error } = await admin.rpc('digi_staff_login_v06', {
      p_pin: pin,
      p_role: 'company_admin',
      p_event_id: eventId,
    });

    const row = firstRow(data);
    if (error || !row?.token) {
      if (error) console.error('company admin event login', error);
      return NextResponse.json({ error: 'הקוד אינו נכון.' }, { status: 401 });
    }

    return NextResponse.json({
      token: row.token,
      user_id: row.user_id,
      user_name: row.user_name,
      role: row.role,
    });
  } catch (error) {
    console.error('staff login route', error);
    return NextResponse.json({ error: 'לא הצלחנו לבצע כניסה.' }, { status: 500 });
  }
}
