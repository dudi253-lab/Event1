import { createClient } from '@supabase/supabase-js';

function serverConfig() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL?.trim() || '';
  const serviceKey =
    process.env.SUPABASE_SECRET_KEY?.trim() ||
    process.env.SUPABASE_SERVICE_ROLE_KEY?.trim() ||
    '';

  return { url, serviceKey };
}

export function getSupabaseAdmin() {
  const { url, serviceKey } = serverConfig();

  if (!url || !serviceKey) {
    throw new Error('Digi server configuration is incomplete. Missing Supabase URL or server secret.');
  }

  return createClient(url, serviceKey, {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
  });
}

export function getServerConfigHealth() {
  const { url, serviceKey } = serverConfig();
  return {
    urlConfigured: Boolean(url),
    secretConfigured: Boolean(serviceKey),
    secretKind: serviceKey.startsWith('sb_secret_')
      ? 'secret'
      : serviceKey.startsWith('eyJ')
        ? 'legacy-service-role'
        : serviceKey
          ? 'unknown'
          : 'missing',
  };
}

export type ValidStaffSession = {
  token: string;
  user_id: string;
  event_id: string | null;
  role: 'company_admin' | 'photo_moderator';
};

export async function getValidStaffSession(
  token: string,
  eventId: string,
  allowedRoles: Array<'company_admin' | 'photo_moderator'>,
): Promise<ValidStaffSession | null> {
  if (!token || !eventId) return null;

  const admin = getSupabaseAdmin();
  const { data: session, error: sessionError } = await admin
    .from('staff_sessions')
    .select('token,user_id,event_id,role,expires_at')
    .eq('token', token)
    .gt('expires_at', new Date().toISOString())
    .maybeSingle();

  if (sessionError) {
    console.error('staff auth session lookup', sessionError);
    return null;
  }
  if (!session || !allowedRoles.includes(session.role)) return null;

  if (session.role === 'photo_moderator') {
    if (session.event_id !== eventId) return null;
    const { data: membership, error } = await admin
      .from('event_staff')
      .select('id')
      .eq('event_id', eventId)
      .eq('user_id', session.user_id)
      .eq('role', 'photo_moderator')
      .eq('active', true)
      .maybeSingle();

    if (error) {
      console.error('staff auth moderator membership', error);
      return null;
    }
    return membership ? (session as ValidStaffSession) : null;
  }

  const { data: event, error: eventError } = await admin
    .from('events')
    .select('company_id')
    .eq('id', eventId)
    .maybeSingle();
  if (eventError || !event) return null;

  const { data: membership, error: membershipError } = await admin
    .from('company_users')
    .select('id')
    .eq('user_id', session.user_id)
    .eq('company_id', event.company_id)
    .eq('active', true)
    .maybeSingle();

  if (membershipError) {
    console.error('staff auth admin membership', membershipError);
    return null;
  }

  return membership ? (session as ValidStaffSession) : null;
}

export async function validStaffToken(
  token: string,
  eventId: string,
  allowedRoles: Array<'company_admin' | 'photo_moderator'>,
) {
  return Boolean(await getValidStaffSession(token, eventId, allowedRoles));
}
