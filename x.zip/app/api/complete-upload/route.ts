import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase-admin';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    const eventId = String(body?.eventId || '');
    const storagePath = String(body?.storagePath || '');
    const originalFilename = body?.originalFilename ? String(body.originalFilename) : null;
    const mimeType = body?.mimeType ? String(body.mimeType) : null;
    const fileSize = Number(body?.fileSize || 0) || null;
    const contentHash = body?.contentHash ? String(body.contentHash) : null;
    const editMetadata =
      body?.editMetadata && typeof body.editMetadata === 'object'
        ? body.editMetadata
        : {};

    if (!eventId || !storagePath) {
      return NextResponse.json({ error: 'פרטי ההעלאה חסרים.' }, { status: 400 });
    }

    const expectedPrefix = `events/${eventId}/pending/`;
    if (!storagePath.startsWith(expectedPrefix)) {
      return NextResponse.json({ error: 'נתיב העלאה לא תקין.' }, { status: 400 });
    }

    const admin = getSupabaseAdmin();

    const { data: event, error: eventError } = await admin
      .from('events')
      .select('id,status')
      .eq('id', eventId)
      .maybeSingle();

    if (eventError) throw eventError;

    const { data: settings, error: settingsError } = await admin
      .from('event_settings')
      .select('uploads_enabled')
      .eq('event_id', eventId)
      .maybeSingle();

    if (settingsError) throw settingsError;

    if (!event || !settings?.uploads_enabled || !['ready', 'live', 'post_event'].includes(event.status)) {
      return NextResponse.json({ error: 'העלאת תמונות אינה פעילה כרגע.' }, { status: 403 });
    }

    const { data: row, error } = await admin
      .from('photos')
      .insert({
        event_id: eventId,
        storage_path: storagePath,
        original_filename: originalFilename,
        mime_type: mimeType,
        file_size: fileSize,
        status: 'pending',
        content_hash: contentHash,
        edit_metadata: editMetadata,
      })
      .select('id')
      .single();

    if (error) {
      const message = String(error.message || '').toLowerCase();

      if (message.includes('duplicate') || error.code === '23505') {
        await admin.storage.from('event-photos').remove([storagePath]).catch(() => undefined);
        return NextResponse.json({ duplicate: true });
      }

      throw error;
    }

    return NextResponse.json({ ok: true, id: row.id, duplicate: false });
  } catch (error) {
    console.error('complete-upload route', error);
    return NextResponse.json(
      { error: 'התמונה עלתה, אבל לא הצלחנו להעביר אותה לאישור.' },
      { status: 500 },
    );
  }
}
