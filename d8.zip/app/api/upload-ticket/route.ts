import crypto from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin, validStaffToken } from '@/lib/supabase-admin';

function safeName(name: string) {
  return name
    .normalize('NFKD')
    .replace(/[^\w.\-]+/g, '-')
    .replace(/-+/g, '-')
    .slice(-100) || 'photo.jpg';
}

function clientHash(request: NextRequest) {
  const raw =
    request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
    request.headers.get('x-real-ip') ||
    'unknown';
  return crypto.createHash('sha256').update(raw).digest('hex');
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const kind = body?.kind === 'cover' ? 'cover' : 'guest';
    const eventId = String(body?.eventId || '');
    const sessionToken = String(body?.sessionToken || '');
    const fileName = safeName(String(body?.fileName || 'photo.jpg'));
    const contentHash = body?.contentHash ? String(body.contentHash) : null;

    if (!eventId) {
      return NextResponse.json({ error: 'אירוע לא תקין.', code: 'EVENT_MISSING' }, { status: 400 });
    }

    const admin = getSupabaseAdmin();

    if (kind === 'cover') {
      const ok = sessionToken && await validStaffToken(sessionToken, eventId, ['company_admin']);
      if (!ok) return NextResponse.json({ error: 'אין הרשאת מנהל.', code: 'ADMIN_REQUIRED' }, { status: 403 });
    } else {
      const { data: event, error: eventError } = await admin
        .from('events')
        .select('id,status')
        .eq('id', eventId)
        .maybeSingle();

      if (eventError) {
        console.error('upload-ticket event lookup', eventError);
        return NextResponse.json({ error: 'Digi לא הצליחה לקרוא את האירוע.', code: 'EVENT_LOOKUP_FAILED' }, { status: 500 });
      }
      if (!event) {
        return NextResponse.json({ error: 'האירוע לא נמצא.', code: 'EVENT_NOT_FOUND' }, { status: 404 });
      }

      let { data: settings, error: settingsError } = await admin
        .from('event_settings')
        .select('uploads_enabled,max_photos_per_upload')
        .eq('event_id', eventId)
        .maybeSingle();

      if (settingsError) {
        console.error('upload-ticket settings lookup', settingsError);
        return NextResponse.json({ error: 'Digi לא הצליחה לקרוא את הגדרות ההעלאה.', code: 'SETTINGS_LOOKUP_FAILED' }, { status: 500 });
      }

      // Auto-repair a missing settings row instead of leaving an active event unusable.
      if (!settings) {
        const { data: repaired, error: repairError } = await admin
          .from('event_settings')
          .upsert({
            event_id: eventId,
            moderation_required: true,
            uploads_enabled: true,
            album_enabled: true,
            downloads_enabled: true,
            max_photos_per_upload: 20,
          }, { onConflict: 'event_id' })
          .select('uploads_enabled,max_photos_per_upload')
          .single();

        if (repairError) {
          console.error('upload-ticket settings repair', repairError);
          return NextResponse.json({ error: 'לא הצלחנו להכין את האירוע להעלאה.', code: 'SETTINGS_REPAIR_FAILED' }, { status: 500 });
        }
        settings = repaired;
      }

      if (!['ready', 'live', 'post_event'].includes(event.status)) {
        return NextResponse.json({ error: 'האירוע עדיין לא פתוח להעלאת תמונות.', code: 'EVENT_NOT_LIVE' }, { status: 403 });
      }

      if (!settings.uploads_enabled) {
        return NextResponse.json({ error: 'העלאת התמונות כבויה בהגדרות האירוע.', code: 'UPLOADS_DISABLED' }, { status: 403 });
      }

      if (contentHash) {
        const { data: duplicate } = await admin
          .from('photos')
          .select('id')
          .eq('event_id', eventId)
          .eq('content_hash', contentHash)
          .limit(1)
          .maybeSingle();

        if (duplicate) return NextResponse.json({ duplicate: true });
      }

      const hash = clientHash(request);
      const since = new Date(Date.now() - 60 * 60 * 1000).toISOString();
      const { count } = await admin
        .from('upload_ticket_log')
        .select('id', { count: 'exact', head: true })
        .eq('event_id', eventId)
        .eq('client_hash', hash)
        .gte('created_at', since);

      if ((count || 0) >= 120) {
        return NextResponse.json({ error: 'בוצעו יותר מדי העלאות בזמן קצר. נסו שוב מאוחר יותר.', code: 'RATE_LIMIT' }, { status: 429 });
      }

      await admin.from('upload_ticket_log').insert({ event_id: eventId, client_hash: hash });
    }

    const bucket = kind === 'cover' ? 'event-assets' : 'event-photos';
    const folder = kind === 'cover' ? 'covers' : 'pending';
    const path = `events/${eventId}/${folder}/${crypto.randomUUID()}-${fileName}`;

    const { data, error } = await admin.storage.from(bucket).createSignedUploadUrl(path);
    if (error || !data?.token) {
      console.error('upload-ticket storage', error);
      return NextResponse.json({ error: 'לא הצלחנו לפתוח מקום לתמונה ב-Supabase Storage.', code: 'STORAGE_TICKET_FAILED' }, { status: 500 });
    }

    return NextResponse.json({ path, token: data.token, bucket, duplicate: false });
  } catch (error) {
    console.error('upload-ticket route', error);
    const message = error instanceof Error ? error.message : String(error);
    const configError = /configuration|API key|JWT|Unauthorized|Invalid/i.test(message);
    return NextResponse.json(
      {
        error: configError
          ? 'חיבור השרת ל-Supabase לא תקין. בדקו את המפתח הסודי של הפרויקט.'
          : 'לא הצלחנו להכין את ההעלאה.',
        code: configError ? 'SUPABASE_SERVER_AUTH' : 'UPLOAD_TICKET_UNKNOWN',
      },
      { status: 500 },
    );
  }
}
