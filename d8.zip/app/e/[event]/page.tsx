'use client';

import Link from 'next/link';
import { ChangeEvent, useEffect, useMemo, useRef, useState } from 'react';
import { useParams } from 'next/navigation';
import { StickerEditor } from '@/components/StickerEditor';
import {
  EventRow,
  eventPublicKey,
  getApprovedPhotos,
  getEventByKey,
  PhotoRow,
  StickerEdit,
  photoSrc,
  uploadGuestPhotos,
} from '@/lib/event-api';
import { supabase } from '@/lib/supabase';

const PAGE_SIZE = 40;

export default function GuestEventPage() {
  const params = useParams<{ event: string }>();
  const eventKey = useMemo(() => String(params?.event || ''), [params]);
  const [event, setEvent] = useState<EventRow | null>(null);
  const [photos, setPhotos] = useState<PhotoRow[]>([]);
  const [hasMore, setHasMore] = useState(false);
  const [files, setFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [stickerEdits, setStickerEdits] = useState<Record<number, StickerEdit[]>>({});
  const [activeEditIndex, setActiveEditIndex] = useState(0);
  const [viewMode, setViewMode] = useState<'feed' | 'grid'>('feed');
  const [busy, setBusy] = useState(false);
  const [uploadProgress, setUploadProgress] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [lightbox, setLightbox] = useState<number | null>(null);
  const lightboxStart = useRef<number | null>(null);

  const loadEvent = async () => {
    const next = await getEventByKey(eventKey);
    setEvent(next);
    return next;
  };

  const loadAlbum = async (eventId: string, wanted = PAGE_SIZE) => {
    const result = await getApprovedPhotos(eventId, 0, wanted);
    setPhotos(result.photos);
    setHasMore(result.has_more);
  };

  useEffect(() => {
    if (!eventKey) return;
    void (async () => {
      try {
        const loaded = await loadEvent();
        await loadAlbum(loaded.id);
      } catch {
        setError('לא הצלחנו לטעון את האירוע.');
      }
    })();
  }, [eventKey]);

  useEffect(() => {
    const next = files.map((file) => URL.createObjectURL(file));
    setPreviews(next);
    return () => next.forEach((url) => URL.revokeObjectURL(url));
  }, [files]);

  useEffect(() => {
    if (!event?.id) return;

    const channel = supabase
      .channel(`digi-public-${event.id}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'photos', filter: `event_id=eq.${event.id}` },
        () => void loadAlbum(event.id, Math.max(PAGE_SIZE, photos.length || PAGE_SIZE)),
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'events', filter: `id=eq.${event.id}` },
        () => void loadEvent(),
      )
      .subscribe();

    const fallback = window.setInterval(() => {
      void loadAlbum(event.id, Math.max(PAGE_SIZE, photos.length || PAGE_SIZE));
    }, 30000);

    return () => {
      window.clearInterval(fallback);
      void supabase.removeChannel(channel);
    };
  }, [event?.id, eventKey, photos.length]);

  const onFiles = (e: ChangeEvent<HTMLInputElement>) => {
    const selected = Array.from(e.target.files ?? []).slice(0, 20);
    e.target.value = '';
    if (!selected.length) return;
    setFiles(selected);
    setStickerEdits({});
    setActiveEditIndex(0);
    setMessage('');
    setError('');
    setUploadProgress('');
  };

  const upload = async () => {
    if (!event || !files.length) return;
    setBusy(true);
    setError('');
    setUploadProgress(`0/${files.length}`);
    try {
      const result = await uploadGuestPhotos(event.id, files, (done, total) => {
        setUploadProgress(`${done}/${total}`);
      }, stickerEdits);
      setFiles([]);
      setStickerEdits({});
      setActiveEditIndex(0);
      setUploadProgress('');
      const duplicateNote = result.skipped ? ` · ${result.skipped} כפולות דולגו` : '';
      setMessage(`הרגעים שלכם בדרך לאלבום ✨${duplicateNote}`);
      window.setTimeout(() => setMessage(''), 5000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'ההעלאה נכשלה. נסו שוב.');
    } finally {
      setBusy(false);
    }
  };

  const loadMore = async () => {
    if (!event || busy) return;
    setBusy(true);
    try {
      const result = await getApprovedPhotos(event.id, photos.length, PAGE_SIZE);
      setPhotos((current) => [...current, ...result.photos]);
      setHasMore(result.has_more);
    } catch {
      setError('לא הצלחנו לטעון תמונות נוספות.');
    } finally {
      setBusy(false);
    }
  };

  const uploadsOpen = Boolean(event && ['ready', 'live', 'post_event'].includes(event.status));
  const moderatorHref = event ? `/e/${eventPublicKey(event)}/moderator` : '#';
  const currentPhoto = lightbox !== null ? photos[lightbox] : null;

  const moveLightbox = (delta: number) => {
    if (!photos.length) return;
    setLightbox((current) => {
      const start = current ?? 0;
      return (start + delta + photos.length) % photos.length;
    });
  };

  const downloadCurrent = async () => {
    if (!currentPhoto?.signed_url) return;
    try {
      const response = await fetch(currentPhoto.signed_url);
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = currentPhoto.original_filename || 'digi-photo.jpg';
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch {
      window.open(currentPhoto.signed_url, '_blank', 'noopener,noreferrer');
    }
  };

  const shareCurrent = async () => {
    if (!currentPhoto?.signed_url) return;
    if (navigator.share) {
      await navigator.share({ title: event?.name || 'Digi', url: currentPhoto.signed_url });
    } else {
      await navigator.clipboard.writeText(currentPhoto.signed_url);
      setMessage('קישור לתמונה הועתק');
      window.setTimeout(() => setMessage(''), 2500);
    }
  };

  const feedTime = (value: string) => {
    const date = new Date(value);
    return Number.isNaN(date.getTime())
      ? ''
      : date.toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <main className="digiAlbumPage">
      <div className="storyOuter">
        <section
          className="digiStory"
          style={
            event?.cover_image
              ? {
                  backgroundImage: `url("${event.cover_image}")`,
                }
              : undefined
          }
        >
          <div className="digiStoryTop">
            <span className="digiWordmark">Digi</span>
            <span className="storyDots" aria-hidden="true">•••</span>
          </div>

          <div className="digiStoryContent">
            <h1>{event?.name || 'האירוע שלכם'}</h1>
            <div className="heroHeartLine" aria-hidden="true"><span>♥</span></div>
            <p>האירוע שלכם, דרך העיניים של כולם.</p>

            {uploadsOpen ? (
              <label className="storyUploadCta">
                <span>שתפו רגע</span><b>＋</b>
                <input type="file" accept="image/*,.heic,.heif" multiple onChange={onFiles} />
              </label>
            ) : (
              <div className="storyClosed">העלאת התמונות עדיין לא נפתחה</div>
            )}
          </div>
        </section>
      </div>

      <section className="albumBody">
        <header className="albumSectionHeader albumSectionHeaderV6">
          <span>האלבום המשותף</span>
          <h2>הרגעים שלנו</h2>
          <div className="albumHeartLine" aria-hidden="true"><span>♥</span></div>
          <small>החדש ביותר תמיד למעלה</small>
          <div className="viewToggle viewToggleV6" aria-label="תצוגת אלבום">
            <button className={viewMode === 'feed' ? 'active' : ''} onClick={() => setViewMode('feed')}>פיד</button>
            <button className={viewMode === 'grid' ? 'active' : ''} onClick={() => setViewMode('grid')}>גריד</button>
          </div>
        </header>

        {error && <div className="inlineError">{error}</div>}

        {photos.length ? (
          <>
            {viewMode === 'feed' ? (
              <div className="digiFeed">
                {photos.map((photo, index) => (
                  <article className="feedCard" key={photo.id}>
                    <header>
                      <span className="feedDigi">Digi</span>
                      <span>{feedTime(photo.uploaded_at)}</span>
                    </header>
                    <button className="feedPhotoButton" onClick={() => setLightbox(index)}>
                      {photoSrc(photo) && (
                        <img loading="lazy" src={photoSrc(photo)} alt={photo.original_filename || 'תמונת אירוע'} />
                      )}
                    </button>
                    <footer>
                      <span>♡</span>
                      <span>רגע מהאירוע</span>
                    </footer>
                  </article>
                ))}
              </div>
            ) : (
              <div className="digiPhotoGrid">
                {photos.map((photo, index) => (
                  <button className="digiPhotoTile" key={photo.id} onClick={() => setLightbox(index)}>
                    {photoSrc(photo) && (
                      <img loading="lazy" src={photoSrc(photo)} alt={photo.original_filename || 'תמונת אירוע'} />
                    )}
                  </button>
                ))}
              </div>
            )}
            {hasMore && (
              <button className="loadMoreButton" onClick={() => void loadMore()} disabled={busy}>
                {busy ? 'טוען…' : 'עוד רגעים'}
              </button>
            )}
          </>
        ) : (
          <div className="albumEmpty">
            <span>✦</span>
            <h3>הרגע הראשון עוד בדרך</h3>
            <p>תמונות שאושרו יופיעו כאן אוטומטית.</p>
          </div>
        )}
      </section>

      <footer className="digiFooter">
        <span>Digi</span>
        <div className="stealthOps">
          {event && <Link href={moderatorHref}>שושבינות</Link>}
          <span>·</span>
          <Link href="/admin">ניהול</Link>
        </div>
      </footer>

      {uploadsOpen && (
        <label className="floatingDigiUpload">
          ＋ העלאת תמונות
          <input type="file" accept="image/*,.heic,.heif" multiple onChange={onFiles} />
        </label>
      )}

      {files.length > 0 && (
        <div className="uploadSheetBackdrop" onClick={() => { if (!busy) { setFiles([]); setStickerEdits({}); } }}>
          <section className="uploadSheet" onClick={(e) => e.stopPropagation()}>
            <div className="sheetHandle" />
            <span className="sheetEyebrow">{files.length} תמונות נבחרו</span>
            <h2>אלה הרגעים שלכם?</h2>
            <p>לפני הפרסום, התמונות יעברו לאישור השושבינות של האירוע הזה בלבד.</p>

            <StickerEditor
              previews={previews}
              activeIndex={activeEditIndex}
              edits={stickerEdits}
              onActiveIndex={setActiveEditIndex}
              onChange={setStickerEdits}
            />

            {error && <div className="inlineError">{error}</div>}
            <button className="primaryButton" onClick={() => void upload()} disabled={busy}>
              {busy ? `מעלה ${uploadProgress}` : `העלאת ${files.length} תמונות`}
            </button>
            <button className="textButton" onClick={() => { setFiles([]); setStickerEdits({}); }} disabled={busy}>ביטול</button>
            <small className="compressionNote">Digi מקטינה תמונות גדולות בחוכמה כדי לחסוך נפח בלי לפגוע בחוויה.</small>
          </section>
        </div>
      )}

      {message && <div className="successToast">✓ {message}</div>}

      {currentPhoto && lightbox !== null && (
        <div
          className="lightbox"
          onClick={() => setLightbox(null)}
          onPointerDown={(e) => { lightboxStart.current = e.clientX; }}
          onPointerUp={(e) => {
            if (lightboxStart.current === null) return;
            const delta = e.clientX - lightboxStart.current;
            lightboxStart.current = null;
            if (delta > 60) moveLightbox(-1);
            if (delta < -60) moveLightbox(1);
          }}
        >
          <button className="lightboxClose" onClick={() => setLightbox(null)}>×</button>
          {photoSrc(currentPhoto) && (
            <img
              src={photoSrc(currentPhoto)}
              alt="תמונה מוגדלת"
              onClick={(e) => e.stopPropagation()}
            />
          )}
          <div className="lightboxToolbar" onClick={(e) => e.stopPropagation()}>
            <button onClick={() => moveLightbox(-1)}>→</button>
            <button onClick={() => void shareCurrent()}>שיתוף</button>
            <span>{lightbox + 1} / {photos.length}</span>
            <button onClick={() => void downloadCurrent()}>הורדה</button>
            <button onClick={() => moveLightbox(1)}>←</button>
          </div>
        </div>
      )}
    </main>
  );
}
