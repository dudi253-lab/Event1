-- Digi v0.6 — clean end-to-end upload/moderation repair
-- Run AFTER the existing Digi schema. Safe to run repeatedly.

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------------
-- Core columns / tables required by the v0.6 server-first flow
-- ---------------------------------------------------------------------------

alter table public.photos add column if not exists content_hash text;
alter table public.photos add column if not exists edit_metadata jsonb not null default '{}'::jsonb;
create unique index if not exists photos_event_hash_uidx
  on public.photos(event_id, content_hash)
  where content_hash is not null;

alter table public.event_staff add column if not exists pin_hash text;
alter table public.staff_sessions alter column event_id drop not null;

create table if not exists public.photo_moderation_log (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.events(id) on delete cascade,
  photo_id uuid not null references public.photos(id) on delete cascade,
  from_status photo_status not null,
  to_status photo_status not null,
  actor_user_id uuid references public.users(id) on delete set null,
  actor_role text not null check (actor_role in ('company_admin','photo_moderator')),
  created_at timestamptz not null default now()
);

create table if not exists public.upload_ticket_log (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.events(id) on delete cascade,
  client_hash text not null,
  created_at timestamptz not null default now()
);
create index if not exists upload_ticket_log_event_client_idx
  on public.upload_ticket_log(event_id, client_hash, created_at desc);

-- ---------------------------------------------------------------------------
-- Repair settings and demo moderator access
-- ---------------------------------------------------------------------------

insert into public.event_settings (
  event_id, moderation_required, uploads_enabled, album_enabled,
  downloads_enabled, max_photos_per_upload
)
select e.id, true,
       (e.status in ('ready','live','post_event')),
       true, true, 20
from public.events e
where not exists (select 1 from public.event_settings s where s.event_id=e.id)
on conflict (event_id) do nothing;

update public.event_settings s
set uploads_enabled = true,
    updated_at = now()
where exists (
  select 1 from public.events e
  where e.id=s.event_id and e.status in ('ready','live','post_event')
);

-- Carry legacy user PINs into event-scoped moderator PINs when needed.
update public.event_staff es
set pin_hash = u.pin_hash
from public.users u
where u.id = es.user_id
  and es.pin_hash is null
  and u.pin_hash is not null;

-- Keep the known demo credentials stable for local testing.
update public.users
set pin_hash = crypt('1234', gen_salt('bf')), active = true
where id = '00000000-0000-0000-0000-00000000a002';

update public.event_staff
set pin_hash = crypt('1234', gen_salt('bf')), active = true
where event_id = '00000000-0000-0000-0000-000000001001'
  and role = 'photo_moderator';

-- ---------------------------------------------------------------------------
-- Dedicated server-only moderator login. It creates an event-scoped session.
-- ---------------------------------------------------------------------------

create or replace function public.digi_staff_login_v06(
  p_pin text,
  p_role text,
  p_event_id uuid
)
returns table (
  token uuid,
  user_id uuid,
  user_name text,
  role text
)
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_user_id uuid;
  v_user_name text;
  v_token uuid := gen_random_uuid();
begin
  if p_pin !~ '^\d{4}$' then
    raise exception 'הקוד אינו נכון';
  end if;

  delete from public.staff_sessions where expires_at < now();

  if p_role = 'photo_moderator' then
    select u.id, u.name
      into v_user_id, v_user_name
    from public.event_staff es
    join public.users u on u.id = es.user_id
    where es.event_id = p_event_id
      and es.role = 'photo_moderator'
      and es.active = true
      and u.active = true
      and es.pin_hash is not null
      and crypt(p_pin, es.pin_hash) = es.pin_hash
    limit 1;
  elsif p_role = 'company_admin' then
    select u.id, u.name
      into v_user_id, v_user_name
    from public.users u
    join public.company_users cu on cu.user_id = u.id and cu.active = true
    join public.events e on e.company_id = cu.company_id
    where e.id = p_event_id
      and u.active = true
      and u.pin_hash is not null
      and crypt(p_pin, u.pin_hash) = u.pin_hash
    limit 1;
  else
    raise exception 'תפקיד לא תקין';
  end if;

  if v_user_id is null then
    raise exception 'הקוד אינו נכון';
  end if;

  insert into public.staff_sessions(token,user_id,event_id,role,expires_at)
  values(v_token,v_user_id,p_event_id,p_role,now()+interval '12 hours');

  return query select v_token,v_user_id,v_user_name,p_role;
end;
$$;

revoke all on function public.digi_staff_login_v06(text,text,uuid) from public, anon, authenticated;
grant execute on function public.digi_staff_login_v06(text,text,uuid) to service_role;

-- ---------------------------------------------------------------------------
-- Server role privileges. RLS stays enabled for public clients; server routes
-- use the service role after checking Digi's own session authorization.
-- ---------------------------------------------------------------------------

grant usage on schema public to service_role;
grant select on public.events, public.event_settings, public.users,
  public.company_users, public.event_staff, public.staff_sessions to service_role;
grant select, insert, update, delete on public.photos to service_role;
grant select, insert on public.photo_moderation_log, public.upload_ticket_log to service_role;

-- Guest clients no longer write photo rows directly in v0.6.
-- The /api/complete-upload route writes pending rows after Storage succeeds.
alter table public.photos enable row level security;
revoke insert on public.photos from anon, authenticated;
drop policy if exists guest_insert_pending_photos on public.photos;

-- Public album can only read approved database rows.
grant select on public.photos to anon, authenticated;
drop policy if exists public_read_approved_photos on public.photos;
create policy public_read_approved_photos
on public.photos for select to anon, authenticated
using (status='approved');

-- ---------------------------------------------------------------------------
-- Storage: private originals + signed guest upload path.
-- ---------------------------------------------------------------------------

update storage.buckets set public=false where id='event-photos';
update storage.buckets set public=true where id='event-assets';

drop policy if exists digi_guest_signed_upload_insert on storage.objects;
create policy digi_guest_signed_upload_insert
on storage.objects
for insert
to anon, authenticated
with check (
  bucket_id='event-photos'
  and (storage.foldername(name))[1]='events'
  and (storage.foldername(name))[3]='pending'
);

drop policy if exists digi_guest_signed_upload_select on storage.objects;
create policy digi_guest_signed_upload_select
on storage.objects
for select
to anon, authenticated
using (
  bucket_id='event-photos'
  and (storage.foldername(name))[1]='events'
  and (storage.foldername(name))[3]='pending'
);

-- Keep old broad upload policies from accidentally overriding the signed path.
drop policy if exists guest_upload_event_photos on storage.objects;

-- ---------------------------------------------------------------------------
-- Realtime for automatic album/moderator refresh.
-- ---------------------------------------------------------------------------

alter table public.events replica identity full;
alter table public.photos replica identity full;

do $$
begin
  if exists (select 1 from pg_publication where pubname='supabase_realtime') then
    if not exists (
      select 1 from pg_publication_tables
      where pubname='supabase_realtime' and schemaname='public' and tablename='events'
    ) then
      alter publication supabase_realtime add table public.events;
    end if;
    if not exists (
      select 1 from pg_publication_tables
      where pubname='supabase_realtime' and schemaname='public' and tablename='photos'
    ) then
      alter publication supabase_realtime add table public.photos;
    end if;
  end if;
end $$;


-- ---------------------------------------------------------------------------
-- v0.7 authoritative staff authorization.
-- The API calls this with the server service-role key. The function validates
-- the live session and the current event membership in one database operation.
-- ---------------------------------------------------------------------------

create or replace function public.digi_valid_staff_v07(
  p_token uuid,
  p_event_id uuid,
  p_roles text[]
)
returns table (
  token uuid,
  user_id uuid,
  event_id uuid,
  role text
)
language sql
security definer
set search_path = public
as $$
  select s.token, s.user_id, s.event_id, s.role
  from public.staff_sessions s
  join public.users u
    on u.id = s.user_id
   and u.active = true
  where s.token = p_token
    and s.expires_at > now()
    and s.role = any(p_roles)
    and (
      (
        s.role = 'photo_moderator'
        and s.event_id = p_event_id
        and exists (
          select 1
          from public.event_staff es
          where es.event_id = p_event_id
            and es.user_id = s.user_id
            and es.role = 'photo_moderator'
            and es.active = true
        )
      )
      or
      (
        s.role = 'company_admin'
        and exists (
          select 1
          from public.events e
          join public.company_users cu
            on cu.company_id = e.company_id
           and cu.user_id = s.user_id
           and cu.active = true
          where e.id = p_event_id
        )
      )
    )
  limit 1;
$$;

revoke all on function public.digi_valid_staff_v07(uuid,uuid,text[])
  from public, anon, authenticated;
grant execute on function public.digi_valid_staff_v07(uuid,uuid,text[])
  to service_role;

-- Explicitly allow the server role to use the v0.6 login function too.
grant execute on function public.digi_staff_login_v06(text,text,uuid)
  to service_role;

-- ---------------------------------------------------------------------------
-- v0.8: restore the proven guest photo-row registration path.
-- v0.5/r.zip successfully used anon INSERT + RLS after the signed Storage upload.
-- v0.6 revoked this and added /api/complete-upload, which is the regression we
-- are removing. Storage stays signed/private; only a pending metadata row may
-- be created for an event whose uploads are enabled.
-- ---------------------------------------------------------------------------

grant select on public.events, public.event_settings to anon, authenticated;
grant select, insert on public.photos to anon, authenticated;

alter table public.photos enable row level security;
drop policy if exists guest_insert_pending_photos on public.photos;
create policy guest_insert_pending_photos
on public.photos
for insert
to anon, authenticated
with check (
  status = 'pending'
  and event_id is not null
  and storage_path like ('events/' || event_id::text || '/pending/%')
  and exists (
    select 1
    from public.events e
    join public.event_settings s on s.event_id = e.id
    where e.id = photos.event_id
      and e.status in ('ready','live','post_event')
      and s.uploads_enabled = true
  )
);

-- Approved rows remain the only guest-readable photo metadata.
drop policy if exists public_read_approved_photos on public.photos;
create policy public_read_approved_photos
on public.photos
for select
to anon, authenticated
using (status = 'approved');

-- Keep the server's direct staff-session validation deterministic.
grant select on public.users, public.company_users, public.event_staff,
  public.staff_sessions, public.events, public.event_settings to service_role;
grant select, insert, update, delete on public.photos to service_role;
grant select, insert on public.photo_moderation_log, public.upload_ticket_log to service_role;

-- Refresh Data API metadata after the migration.
notify pgrst, 'reload schema';
select pg_notification_queue_usage();
