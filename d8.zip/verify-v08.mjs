import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import ts from 'typescript';

const root = new URL('./', import.meta.url);
const checks = [];
function read(relative) {
  return fs.readFileSync(new URL(relative, root), 'utf8');
}
function assert(name, ok) {
  checks.push({ name, ok: Boolean(ok) });
  if (!ok) throw new Error(`FAILED: ${name}`);
}

const eventApi = read('lib/event-api.ts');
const staff = read('lib/supabase-admin.ts');
const layout = read('app/layout.tsx');
const css = read('app/globals.css');
const sql = read('supabase/v0.8.sql');
const guest = read('app/e/[event]/page.tsx');
const moderator = read('app/e/[event]/moderator/page.tsx');
const admin = read('app/admin/page.tsx');
const uploadTicket = read('app/api/upload-ticket/route.ts');
const countdown = read('components/EventCountdown.tsx');

assert('guest upload uses proven direct RLS insert', eventApi.includes("supabase.from('photos').insert"));
assert('guest upload no longer calls complete-upload', !eventApi.includes("fetch('/api/complete-upload'"));
assert('photo DB errors are human-readable', eventApi.includes('DB: ${message}'));
assert('server staff auth uses direct staff_sessions lookup', staff.includes(".from('staff_sessions')"));
assert('Frank Ruhl Libre is actually loaded', layout.includes('Frank_Ruhl_Libre') && layout.includes('--font-frank'));
assert('Heebo is actually loaded', layout.includes('Heebo') && layout.includes('--font-heebo'));
assert('no remote font import remains', !css.includes('fonts.googleapis.com'));
assert('hero uses loaded serif font', css.includes('font-family:var(--font-frank)'));

assert('events have an end timestamp', sql.includes('event_ends_at timestamptz'));
assert('guest RLS enforces the event deadline', sql.includes('now() < e.event_ends_at'));
assert('upload-ticket enforces the event deadline', uploadTicket.includes("code: 'EVENT_ENDED'"));
assert('event update accepts local end time', sql.includes('p_event_ends_local text'));
assert('event end time uses configured timezone', sql.includes("at time zone coalesce(timezone, 'Asia/Jerusalem')"));

assert('per-event moderator code remains event_staff scoped', sql.includes('update public.event_staff') && sql.includes('event_id = p_event_id'));
assert('changing moderator code revokes old sessions', sql.includes('delete from public.staff_sessions s') && sql.includes("s.role = 'photo_moderator'"));
assert('new-event admin UI requires its own moderator code', admin.includes('קוד שושבינות לאישור תמונות'));
assert('admin can change the event moderator code', admin.includes('שמירת קוד חדש'));

assert('guest page renders the countdown', guest.includes('variant="hero"'));
assert('moderator page renders the countdown', moderator.includes('variant="moderator"'));
assert('admin panel renders the countdown', admin.includes('variant="admin"'));
assert('countdown exact label is present', countdown.includes('האירוע נגמר עוד'));
assert('expired event hides guest upload flow', guest.includes("&& !eventEnded"));

assert('admin image panel can approve', admin.includes("adminModerate(photo, 'approved')"));
assert('admin image panel can reject', admin.includes("adminModerate(photo, 'rejected')"));
assert('admin image panel can make private', admin.includes("adminModerate(photo, 'private')"));
assert('admin media remains scoped to selected event', admin.includes('listStaffPhotos(nextSession.token, nextEvent.id'));

let parsed = 0;
const parseFailures = [];
function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (/\.tsx?$/.test(entry.name)) {
      parsed += 1;
      const source = fs.readFileSync(full, 'utf8');
      const file = ts.createSourceFile(
        full,
        source,
        ts.ScriptTarget.Latest,
        true,
        entry.name.endsWith('.tsx') ? ts.ScriptKind.TSX : ts.ScriptKind.TS,
      );
      for (const diagnostic of file.parseDiagnostics) {
        const at = file.getLineAndCharacterOfPosition(diagnostic.start || 0);
        parseFailures.push(`${full}:${at.line + 1}:${at.character + 1} ${ts.flattenDiagnosticMessageText(diagnostic.messageText, ' ')}`);
      }
    }
  }
}
walk(fileURLToPath(root));
assert(`TypeScript/TSX parse clean (${parsed} files)`, parseFailures.length === 0);
if (parseFailures.length) console.error(parseFailures.join('\n'));

console.log(`✅ Digi v0.8 deep preflight passed (${checks.length}/${checks.length})`);
