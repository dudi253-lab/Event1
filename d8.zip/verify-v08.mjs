import fs from 'node:fs';

const checks = [];
function assert(name, ok) {
  checks.push({ name, ok: Boolean(ok) });
  if (!ok) throw new Error(`FAILED: ${name}`);
}

const eventApi = fs.readFileSync(new URL('./lib/event-api.ts', import.meta.url), 'utf8');
const staff = fs.readFileSync(new URL('./lib/supabase-admin.ts', import.meta.url), 'utf8');
const layout = fs.readFileSync(new URL('./app/layout.tsx', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('./app/globals.css', import.meta.url), 'utf8');
const sql = fs.readFileSync(new URL('./supabase/v0.8.sql', import.meta.url), 'utf8');

assert('guest upload uses direct RLS insert', eventApi.includes("supabase.from('photos').insert"));
assert('guest upload no longer calls complete-upload', !eventApi.includes("fetch('/api/complete-upload'"));
assert('v0.8 grants anon photo insert', /grant select, insert on public\.photos to anon, authenticated;/i.test(sql));
assert('v0.8 creates pending-only RLS policy', sql.includes('create policy guest_insert_pending_photos') && sql.includes("status = 'pending'"));
assert('v0.8 binds DB row to signed storage path', sql.includes("storage_path like ('events/' || event_id::text || '/pending/%')"));
assert('staff auth uses direct staff_sessions lookup', staff.includes(".from('staff_sessions')"));
assert('staff auth has no auth RPC call', !staff.includes(".rpc('valid_staff_session") && !staff.includes(".rpc('digi_valid_staff_v07"));
assert('Frank Ruhl Libre is actually loaded', layout.includes('Frank_Ruhl_Libre') && layout.includes('--font-frank'));
assert('Heebo is actually loaded', layout.includes('Heebo') && layout.includes('--font-heebo'));
assert('hero uses loaded serif variable', css.includes('font-family:var(--font-frank)'));
assert('global UI uses loaded Hebrew sans variable', css.includes('font-family:var(--font-heebo)'));

console.log(`✅ Digi v0.8 preflight passed (${checks.length}/${checks.length})`);
