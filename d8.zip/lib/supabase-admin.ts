import { createClient } from '@supabase/supabase-js';

function serverConfig() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL?.trim() || '';
  const serviceKey =
    process.env.SUPABASE_SECRET_KEY?.trim() ||
    process.env.SUPABASE_SERVICE_ROLE_KEY?.trim() ||
    '';

  return { url, serviceKey };
}

export function getSupabaseAdmin() {
  const { url, serviceKey } = serverConfig();

  if (!url || !serviceKey) {
    throw new Error('Digi server configuration is incomplete. Missing Supabase URL or server secret.');
  }

  return createClient(url, serviceKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
      detectSessionInUrl: false,
    },
  });
}

export function getServerConfigHealth() {
  const { url, serviceKey } = serverConfig();
  return {
    urlConfigured: Boolean(url),
    secretConfigured: Boolean(serviceKey),
    secretKind: serviceKey.startsWith('sb_secret_')
      ? 'secret'
      : serviceKey.startsWith('eyJ')
        ? 'legacy-service-role'
        : serviceKey
          ? 'unknown'
          : 'missing',
  };
}

export type ValidStaffSession = {
  token: string;
  user_id: string;
  event_id: string | null;
  role: 'company_admin' | 'photo_moderator';
};

/**
 * Authoritative v0.8 staff authorization.
 *
 * Deliberately uses only direct service-role table reads. Earlier versions
 * bounced through valid_staff_session RPC variants whose EXECUTE grants and
 * schema-cache state changed across migrations. The server client already
 * proves it can read these tables in the same environment, and a service-role
 * client bypasses RLS when it carries no user session.
 */
export async function getValidStaffSession(
  token: string,
  eventId: string,
  allowedRoles: Array<'company_admin' | 'photo_moderator'>,
): Promise<ValidStaffSession | null> {
  if (!token || !eventId || !allowedRoles.length) return null;

  const admin = getSupabaseAdmin();
  const { data: session, error: sessionError } = await admin
    .from('staff_sessions')
    .select('token,user_id,event_id,role,expires_at')
    .eq('token', token)
    .maybeSingle();

  if (sessionError || !session) {
    if (sessionError) console.error('staff session lookup', sessionError);
    return null;
  }

  if (!allowedRoles.includes(session.role as 'company_admin' | 'photo_moderator')) return null;
  if (session.role === 'photo_moderator' && session.event_id !== eventId) return null;
  if (!session.expires_at || new Date(session.expires_at).getTime() <= Date.now()) return null;

  const { data: user, error: userError } = await admin
    .from('users')
    .select('id,active')
    .eq('id', session.user_id)
    .maybeSingle();

  if (userError || !user?.active) {
    if (userError) console.error('staff user lookup', userError);
    return null;
  }

  if (session.role === 'photo_moderator') {
    const { data: membership, error: membershipError } = await admin
      .from('event_staff')
      .select('id')
      .eq('event_id', eventId)
      .eq('user_id', session.user_id)
      .eq('role', 'photo_moderator')
      .eq('active', true)
      .maybeSingle();

    if (membershipError || !membership) {
      if (membershipError) console.error('moderator membership lookup', membershipError);
      return null;
    }
  } else {
    const { data: event, error: eventError } = await admin
      .from('events')
      .select('company_id')
      .eq('id', eventId)
      .maybeSingle();

    if (eventError || !event?.company_id) {
      if (eventError) console.error('admin event lookup', eventError);
      return null;
    }

    const { data: membership, error: membershipError } = await admin
      .from('company_users')
      .select('id')
      .eq('company_id', event.company_id)
      .eq('user_id', session.user_id)
      .eq('active', true)
      .maybeSingle();

    if (membershipError || !membership) {
      if (membershipError) console.error('admin membership lookup', membershipError);
      return null;
    }
  }

  return {
    token: String(session.token),
    user_id: String(session.user_id),
    event_id: session.event_id ? String(session.event_id) : null,
    role: session.role as 'company_admin' | 'photo_moderator',
  };
}

export async function validStaffToken(
  token: string,
  eventId: string,
  allowedRoles: Array<'company_admin' | 'photo_moderator'>,
) {
  return Boolean(await getValidStaffSession(token, eventId, allowedRoles));
}
