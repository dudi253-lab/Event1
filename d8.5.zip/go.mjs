import fs from 'node:fs';
import process from 'node:process';
import pg from 'pg';
import { createClient } from '@supabase/supabase-js';

const { Client } = pg;

function askHidden(prompt) {
  return new Promise((resolve) => {
    const input = process.stdin;
    const output = process.stdout;
    let value = '';
    output.write(prompt);
    input.resume();
    input.setEncoding('utf8');
    if (input.isTTY && input.setRawMode) input.setRawMode(true);

    const onData = (char) => {
      if (char === '\u0003') process.exit(130);
      if (char === '\r' || char === '\n') {
        if (input.isTTY && input.setRawMode) input.setRawMode(false);
        input.pause();
        input.off('data', onData);
        output.write('\n');
        resolve(value);
        return;
      }
      if (char === '\u007f' || char === '\b') {
        value = value.slice(0, -1);
        return;
      }
      value += char;
    };

    input.on('data', onData);
  });
}

function readEnvFile(path) {
  if (!fs.existsSync(path)) return {};
  const out = {};
  for (const raw of fs.readFileSync(path, 'utf8').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const idx = line.indexOf('=');
    if (idx < 1) continue;
    const key = line.slice(0, idx).trim();
    let value = line.slice(idx + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    out[key] = value;
  }
  return out;
}

const password = await askHidden('DB password: ');
const sql = fs.readFileSync(new URL('./supabase/v0.8.sql', import.meta.url), 'utf8');
const env = { ...readEnvFile('.env.local'), ...process.env };

const client = new Client({
  host: 'aws-0-eu-central-2.pooler.supabase.com',
  port: 5432,
  database: 'postgres',
  user: 'postgres.fhlirqpqqvaudhighkww',
  password,
  ssl: { rejectUnauthorized: false },
});

let testEventId = null;
let testModeratorId = null;
let testAdminSessionToken = null;

try {
  await client.connect();
  await client.query(sql);
  await new Promise((resolve) => setTimeout(resolve, 1500));

  const checks = await client.query(`
    select
      to_regclass('public.event_moderator_secrets') is not null as secrets_table,
      to_regprocedure('public.digi_admin_set_moderator_pin_v085(uuid,uuid,text)') is not null as pin_writer,
      to_regprocedure('public.digi_moderator_login_v085(uuid,text)') is not null as moderator_login,
      exists(select 1 from pg_policies where schemaname='public' and tablename='photos' and policyname='guest_insert_pending_photos') as guest_policy,
      exists(select 1 from information_schema.columns where table_schema='public' and table_name='events' and column_name='event_ends_at') as countdown_column
  `);

  const failed = Object.entries(checks.rows[0] || {})
    .filter(([, value]) => value !== true)
    .map(([key]) => key);
  if (failed.length) throw new Error(`DB preflight failed: ${failed.join(', ')}`);

  const adminMembership = await client.query(`
    select cu.company_id, cu.user_id
    from public.company_users cu
    join public.users u on u.id=cu.user_id and u.active=true
    where cu.role='company_admin' and cu.active=true
    order by cu.id
    limit 1
  `);

  const companyId = adminMembership.rows[0]?.company_id;
  const adminUserId = adminMembership.rows[0]?.user_id;
  if (!companyId || !adminUserId) throw new Error('No active company admin found for E2E test.');

  const eventResult = await client.query(`
    insert into public.events(company_id,name,event_type,status,slug)
    values($1,'Digi PIN self-test','test','draft','digi-pin-test-' || replace(gen_random_uuid()::text,'-',''))
    returning id
  `, [companyId]);
  testEventId = eventResult.rows[0].id;

  const moderatorResult = await client.query(`
    insert into public.users(name,phone,active)
    values('Digi PIN self-test','digi-selftest-' || replace(gen_random_uuid()::text,'-',''),true)
    returning id
  `);
  testModeratorId = moderatorResult.rows[0].id;

  await client.query(`
    insert into public.event_staff(event_id,user_id,role,active)
    values($1,$2,'photo_moderator',true)
  `, [testEventId, testModeratorId]);

  const adminSession = await client.query(`
    insert into public.staff_sessions(token,user_id,event_id,role,expires_at)
    values(gen_random_uuid(),$1,null,'company_admin',now()+interval '10 minutes')
    returning token
  `, [adminUserId]);
  testAdminSessionToken = adminSession.rows[0].token;

  const url = String(env.NEXT_PUBLIC_SUPABASE_URL || '').trim();
  const publicKey = String(
    env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ||
    env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
    ''
  ).trim();

  if (!url || !publicKey) throw new Error('Missing public Supabase env for browser RPC E2E test.');

  const supabase = createClient(url, publicKey, {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
  });

  let setError = null;
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const result = await supabase.rpc('digi_admin_set_moderator_pin_v085', {
      p_token: testAdminSessionToken,
      p_event_id: testEventId,
      p_pin: '8642',
    });
    setError = result.error;
    if (!setError) break;
    if (!/schema cache|Could not find the function/i.test(setError.message || '')) break;
    await new Promise((resolve) => setTimeout(resolve, 900));
  }
  if (setError) throw new Error(`Browser PIN writer RPC failed: ${setError.message}`);

  let loginData = null;
  let loginError = null;
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const result = await supabase.rpc('digi_moderator_login_v085', {
      p_event_id: testEventId,
      p_pin: '8642',
    });
    loginData = result.data;
    loginError = result.error;
    if (!loginError) break;
    if (!/schema cache|Could not find the function/i.test(loginError.message || '')) break;
    await new Promise((resolve) => setTimeout(resolve, 900));
  }
  if (loginError) throw new Error(`Browser moderator login RPC failed: ${loginError.message}`);

  const row = Array.isArray(loginData) ? loginData[0] : loginData;
  if (!row?.token || row?.role !== 'photo_moderator') {
    throw new Error('Moderator login returned no valid session.');
  }

  const sessionCheck = await client.query(`
    select exists(
      select 1
      from public.staff_sessions
      where token=$1::uuid
        and event_id=$2::uuid
        and role='photo_moderator'
        and expires_at > now()
    ) as ok
  `, [row.token, testEventId]);

  if (!sessionCheck.rows[0]?.ok) throw new Error('Moderator session was not persisted.');

  console.log('✅ Digi v0.8.5 DB preflight passed');
  console.log('✅ Digi v0.8.5 browser PIN write passed');
  console.log('✅ Digi v0.8.5 moderator PIN login passed');
  console.log('✅ Digi v0.8.5 ready');
} catch (error) {
  console.error('❌ Digi setup failed');
  console.error(error?.message || error);
  process.exitCode = 1;
} finally {
  if (testEventId) {
    await client.query('delete from public.events where id=$1', [testEventId]).catch(() => {});
  }
  if (testModeratorId) {
    await client.query('delete from public.users where id=$1', [testModeratorId]).catch(() => {});
  }
  if (testAdminSessionToken) {
    await client.query('delete from public.staff_sessions where token=$1', [testAdminSessionToken]).catch(() => {});
  }
  await client.end().catch(() => {});
}
