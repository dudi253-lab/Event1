'use client';

import { useEffect, useMemo, useState } from 'react';

function pad(value: number) {
  return String(Math.max(0, value)).padStart(2, '0');
}

function formatEndDate(endAt: string, timeZone = 'Asia/Jerusalem') {
  const date = new Date(endAt);
  if (Number.isNaN(date.getTime())) return '';

  return new Intl.DateTimeFormat('he-IL', {
    timeZone,
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  }).format(date);
}

export function EventCountdown({
  endAt,
  timeZone = 'Asia/Jerusalem',
  variant = 'default',
}: {
  endAt?: string | null;
  timeZone?: string | null;
  variant?: 'default' | 'hero' | 'moderator' | 'admin';
}) {
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    if (!endAt) return;
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, [endAt]);

  const end = useMemo(() => (endAt ? new Date(endAt).getTime() : Number.NaN), [endAt]);
  const valid = Number.isFinite(end);
  const remaining = valid ? Math.max(0, end - now) : 0;
  const ended = valid && end <= now;
  const totalHours = Math.floor(remaining / 3_600_000);
  const minutes = Math.floor((remaining % 3_600_000) / 60_000);
  const seconds = Math.floor((remaining % 60_000) / 1000);

  return (
    <div className={`eventCountdown eventCountdown--${variant}`} data-ended={ended ? 'true' : 'false'}>
      {!valid ? (
        <span className="eventCountdownMissing">זמן הסיום עדיין לא הוגדר</span>
      ) : ended ? (
        <>
          <span className="eventCountdownLabel">האירוע הסתיים</span>
          <small>{formatEndDate(endAt!, timeZone || 'Asia/Jerusalem')}</small>
        </>
      ) : (
        <>
          <div className="eventCountdownLine">
            <span className="eventCountdownLabel">האירוע נגמר עוד</span>
            <strong dir="ltr">{pad(totalHours)}:{pad(minutes)}:{pad(seconds)}</strong>
          </div>
          <small>{formatEndDate(endAt!, timeZone || 'Asia/Jerusalem')}</small>
        </>
      )}
    </div>
  );
}
