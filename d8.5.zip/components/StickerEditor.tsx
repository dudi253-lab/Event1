'use client';

import { PointerEvent, useMemo, useRef, useState } from 'react';
import type { StickerEdit } from '@/lib/event-api';

const STICKERS: Array<Omit<StickerEdit, 'id' | 'x' | 'y' | 'scale'>> = [
  { text: 'רווק 💚', color: '#20c66a', textColor: '#ffffff' },
  { text: 'רווקה 😉', color: '#ff5f8f', textColor: '#ffffff' },
  { text: 'אפשר לגשת ✨', color: '#111111', textColor: '#ffffff' },
  { text: 'פתוח/ה להיכרות 💫', color: '#7c5cff', textColor: '#ffffff' },
  { text: 'TEAM BRIDE 💍', color: '#f4e5d4', textColor: '#2d241f' },
  { text: 'TEAM GROOM 🥂', color: '#dfe8ff', textColor: '#20263a' },
  { text: '😉', color: 'rgba(255,255,255,.92)', textColor: '#111111' },
  { text: '🔥', color: 'rgba(255,255,255,.92)', textColor: '#111111' },
];

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value));
}

export function StickerEditor({
  previews,
  activeIndex,
  edits,
  onActiveIndex,
  onChange,
}: {
  previews: string[];
  activeIndex: number;
  edits: Record<number, StickerEdit[]>;
  onActiveIndex: (index: number) => void;
  onChange: (next: Record<number, StickerEdit[]>) => void;
}) {
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const stageRef = useRef<HTMLDivElement | null>(null);
  const dragRef = useRef<{
    id: string;
    startClientX: number;
    startClientY: number;
    startX: number;
    startY: number;
  } | null>(null);

  const current = useMemo(() => edits[activeIndex] || [], [edits, activeIndex]);
  const preview = previews[activeIndex];

  const replaceCurrent = (next: StickerEdit[]) => {
    onChange({ ...edits, [activeIndex]: next });
  };

  const addSticker = (preset: (typeof STICKERS)[number]) => {
    const sticker: StickerEdit = {
      ...preset,
      id: crypto.randomUUID(),
      x: 50,
      y: 55,
      scale: 1,
    };
    replaceCurrent([...current, sticker]);
    setSelectedId(sticker.id);
  };

  const updateSticker = (id: string, patch: Partial<StickerEdit>) => {
    replaceCurrent(current.map((item) => (item.id === id ? { ...item, ...patch } : item)));
  };

  const onStickerDown = (event: PointerEvent<HTMLButtonElement>, sticker: StickerEdit) => {
    event.preventDefault();
    event.stopPropagation();
    setSelectedId(sticker.id);
    event.currentTarget.setPointerCapture(event.pointerId);
    dragRef.current = {
      id: sticker.id,
      startClientX: event.clientX,
      startClientY: event.clientY,
      startX: sticker.x,
      startY: sticker.y,
    };
  };

  const onStickerMove = (event: PointerEvent<HTMLButtonElement>) => {
    const drag = dragRef.current;
    const stage = stageRef.current;
    if (!drag || !stage) return;
    const rect = stage.getBoundingClientRect();
    const dx = ((event.clientX - drag.startClientX) / Math.max(rect.width, 1)) * 100;
    const dy = ((event.clientY - drag.startClientY) / Math.max(rect.height, 1)) * 100;
    updateSticker(drag.id, {
      x: clamp(drag.startX + dx, 8, 92),
      y: clamp(drag.startY + dy, 8, 92),
    });
  };

  const selected = current.find((item) => item.id === selectedId) || null;

  if (!preview) return null;

  return (
    <section className="stickerEditor">
      <div className="editorTopline">
        <strong>עריכת תמונה</strong>
        <span>{activeIndex + 1} / {previews.length}</span>
      </div>

      <div className="stickerStage" ref={stageRef} onPointerDown={() => setSelectedId(null)}>
        <img src={preview} alt="תצוגה מקדימה לעריכה" />
        {current.map((sticker) => (
          <button
            type="button"
            key={sticker.id}
            className={`placedSticker${selectedId === sticker.id ? ' selected' : ''}`}
            style={{
              left: `${sticker.x}%`,
              top: `${sticker.y}%`,
              transform: `translate(-50%,-50%) scale(${sticker.scale})`,
              background: sticker.color,
              color: sticker.textColor,
            }}
            onPointerDown={(event) => onStickerDown(event, sticker)}
            onPointerMove={onStickerMove}
            onPointerUp={() => { dragRef.current = null; }}
            onPointerCancel={() => { dragRef.current = null; }}
          >
            {sticker.text}
          </button>
        ))}
      </div>

      {previews.length > 1 && (
        <div className="editorFilmstrip">
          {previews.map((url, index) => (
            <button
              type="button"
              key={url}
              className={index === activeIndex ? 'active' : ''}
              onClick={() => { onActiveIndex(index); setSelectedId(null); }}
            >
              <img src={url} alt={`תמונה ${index + 1}`} />
              {(edits[index]?.length || 0) > 0 && <span>✦</span>}
            </button>
          ))}
        </div>
      )}

      <div className="stickerPalette" aria-label="מדבקות">
        {STICKERS.map((preset) => (
          <button
            type="button"
            key={preset.text}
            style={{ background: preset.color, color: preset.textColor }}
            onClick={() => addSticker(preset)}
          >
            {preset.text}
          </button>
        ))}
      </div>

      <div className="stickerTools">
        <button
          type="button"
          disabled={!selected}
          onClick={() => selected && updateSticker(selected.id, { scale: clamp(selected.scale - 0.12, 0.65, 1.8) })}
        >− קטן</button>
        <button
          type="button"
          disabled={!selected}
          onClick={() => selected && updateSticker(selected.id, { scale: clamp(selected.scale + 0.12, 0.65, 1.8) })}
        >＋ גדול</button>
        <button
          type="button"
          disabled={!selected}
          onClick={() => {
            if (!selected) return;
            replaceCurrent(current.filter((item) => item.id !== selected.id));
            setSelectedId(null);
          }}
        >הסר</button>
        <button
          type="button"
          disabled={!current.length}
          onClick={() => { replaceCurrent([]); setSelectedId(null); }}
        >נקה הכל</button>
      </div>
      <small className="stickerConsent">מדבקות היכרות הן בחירה אישית בלבד. הוסיפו אותן רק לתמונה שלכם או בהסכמה.</small>
    </section>
  );
}
