import { redirect } from 'next/navigation';

export default function LegacyModeratorPage() {
  redirect('/');
}
