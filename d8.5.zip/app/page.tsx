import Link from 'next/link';
import { Logo } from '@/components/Logo';

export default function Home() {
  return (
    <main className="digiHome">
      <section className="homeCard">
        <Logo />
        <div className="homeCopy">
          <span>Digi</span>
          <h1>האירוע שלכם.<br />דרך העיניים של כולם.</h1>
          <p>האורחים נכנסים דרך הקישור או ה־QR הייחודי של האירוע שלהם.</p>
        </div>
        <Link className="homeAdminLink" href="/admin">כניסת מנהלים</Link>
      </section>
    </main>
  );
}
