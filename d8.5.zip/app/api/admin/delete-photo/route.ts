import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin, validStaffToken } from '@/lib/supabase-admin';

export async function POST(request: NextRequest) {
  try {
    const { token, eventId, photoId } = await request.json();

    if (!token || !eventId || !photoId) {
      return NextResponse.json({ error: 'בקשה לא תקינה.' }, { status: 400 });
    }

    const allowed = await validStaffToken(String(token), String(eventId), ['company_admin']);
    if (!allowed) return NextResponse.json({ error: 'אין הרשאת מנהל.' }, { status: 403 });

    const admin = getSupabaseAdmin();
    const { data: photo, error } = await admin
      .from('photos')
      .select('id,event_id,storage_path,preview_path,thumbnail_path')
      .eq('id', photoId)
      .eq('event_id', eventId)
      .maybeSingle();

    if (error || !photo) {
      return NextResponse.json({ error: 'התמונה לא נמצאה.' }, { status: 404 });
    }

    const paths = [photo.storage_path, photo.preview_path, photo.thumbnail_path].filter(Boolean) as string[];
    if (paths.length) {
      const { error: removeError } = await admin.storage.from('event-photos').remove(paths);
      if (removeError) throw removeError;
    }

    const { error: deleteError } = await admin.from('photos').delete().eq('id', photoId);
    if (deleteError) throw deleteError;

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error('delete photo route', error);
    return NextResponse.json({ error: 'המחיקה נכשלה.' }, { status: 500 });
  }
}
