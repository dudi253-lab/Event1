import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin, validStaffToken } from '@/lib/supabase-admin';

const ALLOWED = new Set(['approved', 'pending', 'private', 'rejected']);

export async function GET(request: NextRequest) {
  try {
    const eventId = request.nextUrl.searchParams.get('eventId') || '';
    const status = request.nextUrl.searchParams.get('status') || 'approved';
    const token = request.headers.get('x-digi-session') || request.nextUrl.searchParams.get('token') || '';
    const offset = Math.max(0, Number(request.nextUrl.searchParams.get('offset') || 0));
    const limit = Math.min(80, Math.max(1, Number(request.nextUrl.searchParams.get('limit') || 40)));

    if (!eventId || (!ALLOWED.has(status) && status !== 'all')) {
      return NextResponse.json({ error: 'בקשה לא תקינה.' }, { status: 400 });
    }

    const admin = getSupabaseAdmin();

    if (status !== 'approved') {
      const ok = token && await validStaffToken(token, eventId, ['company_admin', 'photo_moderator']);
      if (!ok) return NextResponse.json({ error: 'אין הרשאה.' }, { status: 403 });
    } else if (token) {
      const ok = await validStaffToken(token, eventId, ['company_admin', 'photo_moderator']);
      if (!ok) return NextResponse.json({ error: 'אין הרשאה.' }, { status: 403 });
    }

    if (status === 'all') {
      const adminOnly = await validStaffToken(token, eventId, ['company_admin']);
      if (!adminOnly) return NextResponse.json({ error: 'אין הרשאת מנהל.' }, { status: 403 });
    }

    let query = admin
      .from('photos')
      .select('id,event_id,storage_path,preview_path,thumbnail_path,original_filename,mime_type,file_size,width,height,status,content_hash,edit_metadata,uploaded_at,moderated_at')
      .eq('event_id', eventId)
      .order('uploaded_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (status !== 'all') query = query.eq('status', status);

    const { data: rows, error } = await query;
    if (error) throw error;

    const paths = (rows || []).map((row) => row.storage_path);
    const { data: signed, error: signError } = paths.length
      ? await admin.storage.from('event-photos').createSignedUrls(paths, 60 * 60)
      : { data: [], error: null };

    if (signError) throw signError;

    const byPath = new Map((signed || []).map((item) => [item.path, item.signedUrl]));
    const photos = (rows || []).map((row) => ({ ...row, signed_url: byPath.get(row.storage_path) || null }));

    return NextResponse.json({
      photos,
      has_more: photos.length === limit,
      next_offset: offset + photos.length,
    });
  } catch (error) {
    console.error('media route', error);
    const message = error instanceof Error ? error.message : String(error);
    const configError = /API key|JWT|Unauthorized|Invalid/i.test(message);
    return NextResponse.json(
      { error: configError ? 'חיבור השרת ל-Supabase לא תקין.' : 'לא הצלחנו לטעון את התמונות.' },
      { status: 500 },
    );
  }
}
