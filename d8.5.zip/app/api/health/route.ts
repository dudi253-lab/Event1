import { NextResponse } from 'next/server';
import { getServerConfigHealth, getSupabaseAdmin } from '@/lib/supabase-admin';

export async function GET() {
  const config = getServerConfigHealth();
  if (!config.urlConfigured || !config.secretConfigured) {
    return NextResponse.json({ ok: false, config, supabase: false }, { status: 503 });
  }

  try {
    const admin = getSupabaseAdmin();
    const { count, error } = await admin
      .from('events')
      .select('id', { count: 'exact', head: true });
    if (error) throw error;
    return NextResponse.json({ ok: true, config, supabase: true, events: count || 0 });
  } catch (error) {
    return NextResponse.json({
      ok: false,
      config,
      supabase: false,
      error: error instanceof Error ? error.message : 'Supabase connection failed',
    }, { status: 500 });
  }
}
