import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin, getValidStaffSession } from '@/lib/supabase-admin';

const ALLOWED = new Set(['pending', 'approved', 'private', 'rejected']);

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const token = String(body?.token || '');
    const photoId = String(body?.photoId || '');
    const status = String(body?.status || '');
    const expectedStatus = body?.expectedStatus ? String(body.expectedStatus) : null;

    if (!token || !photoId || !ALLOWED.has(status) || (expectedStatus && !ALLOWED.has(expectedStatus))) {
      return NextResponse.json({ error: 'בקשה לא תקינה.' }, { status: 400 });
    }

    const admin = getSupabaseAdmin();
    const { data: photo, error: photoError } = await admin
      .from('photos')
      .select('id,event_id,status')
      .eq('id', photoId)
      .maybeSingle();

    if (photoError) throw photoError;
    if (!photo) return NextResponse.json({ error: 'התמונה לא נמצאה.' }, { status: 404 });

    const session = await getValidStaffSession(token, photo.event_id, ['company_admin', 'photo_moderator']);
    if (!session) return NextResponse.json({ error: 'אין הרשאה.' }, { status: 403 });

    if (expectedStatus && photo.status !== expectedStatus) {
      return NextResponse.json({ error: 'התמונה כבר טופלה על ידי משתמש אחר.' }, { status: 409 });
    }

    const { data: updated, error: updateError } = await admin
      .from('photos')
      .update({
        status,
        moderated_at: status === 'pending' ? null : new Date().toISOString(),
        moderated_by: status === 'pending' ? null : session.user_id,
      })
      .eq('id', photoId)
      .eq('status', photo.status)
      .select('id')
      .maybeSingle();

    if (updateError) throw updateError;
    if (!updated) {
      return NextResponse.json({ error: 'התמונה כבר טופלה על ידי משתמש אחר.' }, { status: 409 });
    }

    await admin.from('photo_moderation_log').insert({
      event_id: photo.event_id,
      photo_id: photoId,
      from_status: photo.status,
      to_status: status,
      actor_user_id: session.user_id,
      actor_role: session.role,
    });

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error('staff moderate route', error);
    return NextResponse.json({ error: 'הפעולה נכשלה.' }, { status: 500 });
  }
}
