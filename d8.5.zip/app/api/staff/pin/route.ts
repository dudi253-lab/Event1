import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseAdmin } from '@/lib/supabase-admin';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const token = String(body?.token || '');
    const eventId = String(body?.eventId || '');
    const pin = String(body?.pin || '').replace(/\D/g, '').slice(0, 4);

    if (!token || !eventId || !/^\d{4}$/.test(pin)) {
      return NextResponse.json({ error: 'יש לבחור קוד בן 4 ספרות.' }, { status: 400 });
    }

    const admin = getSupabaseAdmin();
    const { error } = await admin.rpc('digi_admin_set_moderator_pin_v085', {
      p_token: token,
      p_event_id: eventId,
      p_pin: pin,
    });

    if (error) {
      console.error('moderator pin update', error);
      const status = /אין הרשאת מנהל/.test(error.message || '') ? 403 : 500;
      return NextResponse.json({ error: error.message || 'עדכון הקוד נכשל.' }, { status });
    }

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error('moderator pin route', error);
    return NextResponse.json({ error: 'עדכון הקוד נכשל.' }, { status: 500 });
  }
}
