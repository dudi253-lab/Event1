import type { Metadata, Viewport } from 'next';
import { Frank_Ruhl_Libre, Heebo } from 'next/font/google';
import './globals.css';

const heebo = Heebo({
  weight: ['400', '500', '600', '700', '800', '900'],
  subsets: ['hebrew', 'latin'],
  display: 'swap',
  variable: '--font-heebo',
});

const frank = Frank_Ruhl_Libre({
  weight: ['300', '400', '500', '600'],
  subsets: ['hebrew', 'latin'],
  display: 'swap',
  variable: '--font-frank',
});

export const metadata: Metadata = {
  title: 'Digi — האירוע שלכם, דרך העיניים של כולם',
  description: 'אלבום אירוע משותף עם העלאה מהירה, אישור תמונות ו־QR/NFC.',
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  viewportFit: 'cover',
  themeColor: '#ffffff',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="he" dir="rtl" className={`${heebo.variable} ${frank.variable}`} suppressHydrationWarning>
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
