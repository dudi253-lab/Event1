import { supabase } from '@/lib/supabase';

export type EventStatus = 'draft' | 'ready' | 'live' | 'post_event' | 'archived';
export type PhotoStatus = 'pending' | 'approved' | 'private' | 'rejected';

export type StickerEdit = {
  id: string;
  text: string;
  x: number;
  y: number;
  scale: number;
  color: string;
  textColor: string;
};

export type EventRow = {
  id: string;
  company_id: string;
  name: string;
  event_type: string | null;
  event_date: string | null;
  event_time: string | null;
  location: string | null;
  timezone?: string | null;
  event_ends_at?: string | null;
  status: EventStatus;
  slug: string;
  public_id: string | null;
  cover_image: string | null;
  logo_url: string | null;
  primary_color: string;
  secondary_color: string;
  created_at?: string;
  updated_at: string;
};

export type PhotoRow = {
  id: string;
  event_id: string;
  storage_path: string;
  preview_path?: string | null;
  thumbnail_path?: string | null;
  original_filename: string | null;
  mime_type: string | null;
  file_size: number | null;
  width?: number | null;
  height?: number | null;
  status: PhotoStatus;
  content_hash?: string | null;
  uploaded_at: string;
  moderated_at?: string | null;
  edit_metadata?: { stickers?: StickerEdit[] } | null;
  signed_url?: string | null;
};

export type StaffRole = 'company_admin' | 'photo_moderator';

export type StaffSession = {
  token: string;
  user_id: string;
  user_name: string;
  role: StaffRole;
};

export type AdminSession = StaffSession & {
  company_id: string;
};

export type EventStats = {
  total: number;
  pending: number;
  approved: number;
  private_count: number;
  rejected: number;
  storage_bytes: number;
};

export type EventHealth = {
  moderator_ready: boolean;
  settings_ready: boolean;
  cover_ready: boolean;
  public_link_ready: boolean;
};

export function eventPublicKey(event: EventRow) {
  return event.public_id || event.slug;
}

export function photoSrc(photo: PhotoRow) {
  return photo.signed_url || '';
}

export function publicAssetUrl(path: string, bucket = 'event-assets') {
  return supabase.storage.from(bucket).getPublicUrl(path).data.publicUrl;
}

export async function getEventByKey(key: string) {
  const clean = key.trim();
  if (!clean) throw new Error('אירוע לא נמצא.');

  const publicLookup = await supabase
    .from('events')
    .select('*')
    .eq('public_id', clean.toUpperCase())
    .maybeSingle();

  if (!publicLookup.error && publicLookup.data) return publicLookup.data as EventRow;

  const slugLookup = await supabase
    .from('events')
    .select('*')
    .eq('slug', clean)
    .maybeSingle();

  if (slugLookup.error) throw slugLookup.error;
  if (!slugLookup.data) throw new Error('אירוע לא נמצא.');
  return slugLookup.data as EventRow;
}

async function mediaRequest(
  eventId: string,
  status: PhotoStatus | 'all',
  options: { token?: string; offset?: number; limit?: number } = {},
) {
  const params = new URLSearchParams({
    eventId,
    status,
    offset: String(options.offset || 0),
    limit: String(options.limit || 40),
  });
  if (options.token) params.set('token', options.token);

  const response = await fetch(`/api/media?${params.toString()}`, {
    cache: 'no-store',
    headers: options.token ? { 'x-digi-session': options.token } : undefined,
  });
  const payload = await response.json();
  if (!response.ok) throw new Error(payload?.error || 'לא הצלחנו לטעון את התמונות.');

  return payload as { photos: PhotoRow[]; has_more: boolean; next_offset: number };
}

export async function getApprovedPhotos(eventId: string, offset = 0, limit = 40) {
  return mediaRequest(eventId, 'approved', { offset, limit });
}

export async function listStaffPhotos(
  token: string,
  eventId: string,
  status: PhotoStatus | 'all',
  offset = 0,
  limit = 60,
) {
  return mediaRequest(eventId, status, { token, offset, limit });
}

function safeFileName(name: string) {
  const cleaned = name
    .normalize('NFKD')
    .replace(/[^\w.\-]+/g, '-')
    .replace(/-+/g, '-')
    .slice(-100);
  return cleaned || 'photo.jpg';
}

function shouldCompress(file: File) {
  if (!file.type.startsWith('image/')) return false;
  if (/gif|svg/i.test(file.type)) return false;
  return file.size > 1_500_000 || /hei[cf]/i.test(file.type) || /\.hei[cf]$/i.test(file.name);
}

async function loadImage(file: File) {
  const url = URL.createObjectURL(file);
  try {
    const img = new Image();
    img.decoding = 'async';
    await new Promise<void>((resolve, reject) => {
      img.onload = () => resolve();
      img.onerror = () => reject(new Error('Image decode failed'));
      img.src = url;
    });
    return { img, url };
  } catch (error) {
    URL.revokeObjectURL(url);
    throw error;
  }
}

export async function compressForUpload(file: File, maxSide = 2560) {
  if (!shouldCompress(file)) return file;

  try {
    const { img, url } = await loadImage(file);
    const scale = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight));
    const width = Math.max(1, Math.round(img.naturalWidth * scale));
    const height = Math.max(1, Math.round(img.naturalHeight * scale));
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const context = canvas.getContext('2d', { alpha: false });
    if (!context) {
      URL.revokeObjectURL(url);
      return file;
    }

    context.drawImage(img, 0, 0, width, height);
    URL.revokeObjectURL(url);

    const blob = await new Promise<Blob | null>((resolve) =>
      canvas.toBlob(resolve, 'image/jpeg', 0.84),
    );

    if (!blob || (blob.size >= file.size && !/hei[cf]/i.test(file.type))) return file;

    const base = safeFileName(file.name).replace(/\.[^.]+$/, '') || 'photo';
    return new File([blob], `${base}.jpg`, {
      type: 'image/jpeg',
      lastModified: file.lastModified,
    });
  } catch {
    // If the browser cannot decode HEIC, upload the original rather than failing.
    return file;
  }
}

async function sha256(file: File) {
  const buffer = await file.arrayBuffer();
  const digest = await crypto.subtle.digest('SHA-256', buffer);
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, '0')).join('');
}

async function uploadTicket(values: {
  kind: 'guest' | 'cover';
  eventId: string;
  sessionToken?: string;
  fileName: string;
  contentType: string;
  contentHash?: string;
}) {
  const response = await fetch('/api/upload-ticket', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(values),
  });
  const payload = await response.json();
  if (!response.ok) throw new Error(payload?.error || 'לא הצלחנו להכין את ההעלאה.');
  return payload as {
    path?: string;
    token?: string;
    bucket?: string;
    duplicate?: boolean;
  };
}

async function signedUpload(bucket: string, path: string, token: string, file: File) {
  let lastError: unknown = null;

  for (let attempt = 0; attempt < 2; attempt += 1) {
    const { error } = await supabase.storage.from(bucket).uploadToSignedUrl(path, token, file, {
      cacheControl: '3600',
      contentType: file.type || undefined,
    });

    if (!error) return;
    lastError = error;
    await new Promise((resolve) => window.setTimeout(resolve, 500 + attempt * 600));
  }

  throw lastError || new Error('ההעלאה נכשלה.');
}

function roundedRectPath(
  context: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number,
) {
  const r = Math.min(radius, width / 2, height / 2);
  context.beginPath();
  context.moveTo(x + r, y);
  context.arcTo(x + width, y, x + width, y + height, r);
  context.arcTo(x + width, y + height, x, y + height, r);
  context.arcTo(x, y + height, x, y, r);
  context.arcTo(x, y, x + width, y, r);
  context.closePath();
}

async function renderStickerEdits(file: File, edits: StickerEdit[], maxSide = 2560) {
  if (!edits.length) return compressForUpload(file, maxSide);

  const { img, url } = await loadImage(file);
  try {
    const scale = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight));
    const width = Math.max(1, Math.round(img.naturalWidth * scale));
    const height = Math.max(1, Math.round(img.naturalHeight * scale));
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const context = canvas.getContext('2d', { alpha: false });
    if (!context) throw new Error('לא הצלחנו לפתוח את עורך התמונה.');

    context.drawImage(img, 0, 0, width, height);

    for (const sticker of edits) {
      const fontSize = Math.max(24, Math.round(Math.min(width, height) * 0.045 * sticker.scale));
      context.font = `700 ${fontSize}px -apple-system, BlinkMacSystemFont, Arial, sans-serif`;
      context.textAlign = 'center';
      context.textBaseline = 'middle';
      const metrics = context.measureText(sticker.text);
      const padX = Math.round(fontSize * 0.65);
      const padY = Math.round(fontSize * 0.38);
      const boxWidth = Math.min(width * 0.88, metrics.width + padX * 2);
      const boxHeight = fontSize + padY * 2;
      const cx = (sticker.x / 100) * width;
      const cy = (sticker.y / 100) * height;
      const x = Math.max(8, Math.min(width - boxWidth - 8, cx - boxWidth / 2));
      const y = Math.max(8, Math.min(height - boxHeight - 8, cy - boxHeight / 2));

      context.save();
      context.shadowColor = 'rgba(0,0,0,.18)';
      context.shadowBlur = Math.max(6, fontSize * 0.18);
      roundedRectPath(context, x, y, boxWidth, boxHeight, boxHeight / 2);
      context.fillStyle = sticker.color;
      context.fill();
      context.shadowColor = 'transparent';
      context.fillStyle = sticker.textColor;
      context.fillText(sticker.text, x + boxWidth / 2, y + boxHeight / 2 + 1);
      context.restore();
    }

    const blob = await new Promise<Blob | null>((resolve) =>
      canvas.toBlob(resolve, 'image/jpeg', 0.88),
    );
    if (!blob) throw new Error('לא הצלחנו לשמור את עריכת התמונה.');
    const base = safeFileName(file.name).replace(/\.[^.]+$/, '') || 'photo';
    return new File([blob], `${base}-digi.jpg`, {
      type: 'image/jpeg',
      lastModified: file.lastModified,
    });
  } finally {
    URL.revokeObjectURL(url);
  }
}

export async function uploadGuestPhotos(
  eventId: string,
  files: File[],
  onProgress?: (done: number, total: number) => void,
  stickerEdits: Record<number, StickerEdit[]> = {},
) {
  const batch = files.slice(0, 20);
  let uploaded = 0;
  let skipped = 0;

  for (let index = 0; index < batch.length; index += 1) {
    const original = batch[index];
    const edits = stickerEdits[index] || [];
    const file = await renderStickerEdits(original, edits);
    const hash = await sha256(file);

    const ticket = await uploadTicket({
      kind: 'guest',
      eventId,
      fileName: file.name,
      contentType: file.type,
      contentHash: hash,
    });

    if (ticket.duplicate) {
      skipped += 1;
      onProgress?.(index + 1, batch.length);
      continue;
    }

    if (!ticket.bucket || !ticket.path || !ticket.token) {
      throw new Error('לא הצלחנו להכין את ההעלאה.');
    }

    await signedUpload(ticket.bucket, ticket.path, ticket.token, file);

    // This is intentionally a direct anon insert guarded by the database RLS
    // policy. This exact path was already proven end-to-end in v0.5/r.zip.
    // v0.6 moved the same write into /api/complete-upload and introduced the
    // persistent regression, so v0.8 removes that extra server hop entirely.
    const { error: rowError } = await supabase.from('photos').insert({
      event_id: eventId,
      storage_path: ticket.path,
      original_filename: original.name,
      mime_type: file.type || null,
      file_size: file.size,
      status: 'pending',
      content_hash: hash,
      edit_metadata: edits.length ? { stickers: edits } : {},
    });

    if (rowError) {
      const message = String(rowError.message || rowError.details || rowError.hint || 'Database insert failed');
      if (rowError.code === '23505' || /duplicate/i.test(message)) skipped += 1;
      else throw new Error(`DB: ${message}`);
    } else {
      uploaded += 1;
    }

    onProgress?.(index + 1, batch.length);
  }

  return { uploaded, skipped };
}

export async function uploadEventCover(token: string, eventId: string, input: File) {
  const file = await compressForUpload(input, 2800);
  const ticket = await uploadTicket({
    kind: 'cover',
    eventId,
    sessionToken: token,
    fileName: file.name,
    contentType: file.type,
  });

  if (!ticket.bucket || !ticket.path || !ticket.token) {
    throw new Error('לא הצלחנו להכין את תמונת הקאבר.');
  }

  await signedUpload(ticket.bucket, ticket.path, ticket.token, file);
  return publicAssetUrl(ticket.path, 'event-assets');
}

export async function staffLogin(pin: string, role: StaffRole, eventId: string) {
  if (role === 'photo_moderator') {
    const { data, error } = await supabase.rpc('digi_moderator_login_v085', {
      p_event_id: eventId,
      p_pin: pin,
    });

    if (error) throw new Error(error.message || 'הקוד אינו נכון.');
    const row = Array.isArray(data) ? data[0] : data;
    if (!row?.token) throw new Error('הקוד אינו נכון.');
    return row as StaffSession;
  }

  const response = await fetch('/api/staff/login', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ pin, role, eventId }),
  });
  const payload = await response.json();
  if (!response.ok || !payload?.token) throw new Error(payload?.error || 'הקוד אינו נכון.');
  return payload as StaffSession;
}

export async function companyAdminLogin(pin: string) {
  const { data, error } = await supabase.rpc('company_admin_pin_login', { p_pin: pin });
  if (error) throw error;
  const row = Array.isArray(data) ? data[0] : data;
  if (!row?.token) throw new Error('הקוד אינו נכון.');
  return row as AdminSession;
}

export async function listCompanyEvents(token: string) {
  const { data, error } = await supabase.rpc('list_company_events', { p_token: token });
  if (error) throw error;
  return (data || []) as EventRow[];
}

export async function createCompanyEvent(
  token: string,
  values: {
    name: string;
    eventType: string;
    eventDate?: string;
    moderatorPin: string;
    eventEndsLocal?: string | null;
  },
) {
  const { data, error } = await supabase.rpc('create_company_event', {
    p_token: token,
    p_name: values.name,
    p_event_type: values.eventType,
    p_event_date: values.eventDate || null,
    p_moderator_pin: values.moderatorPin,
  });

  if (error) throw error;
  const row = Array.isArray(data) ? data[0] : data;
  if (!row?.id) throw new Error('יצירת האירוע נכשלה.');

  // v0.8.1 keeps one private, canonical moderator PIN per event. The legacy
  // create_company_event RPC still creates the moderator membership, then this
  // server-authorized call initializes the canonical PIN record immediately.
  await setEventModeratorPin(token, row.id, values.moderatorPin);

  if (values.eventEndsLocal) {
    return updateEvent(token, row.id, {
      name: row.name,
      eventType: row.event_type || values.eventType || 'אירוע',
      eventDate: row.event_date || values.eventDate || null,
      location: row.location || '',
      status: row.status,
      coverImage: row.cover_image || null,
      eventEndsLocal: values.eventEndsLocal,
    });
  }

  return row as EventRow;
}

export async function setEventModeratorPin(token: string, eventId: string, pin: string) {
  const cleanPin = pin.replace(/\D/g, '').slice(0, 4);
  if (!/^\d{4}$/.test(cleanPin)) {
    throw new Error('יש לבחור קוד בן 4 ספרות.');
  }

  const { error } = await supabase.rpc('digi_admin_set_moderator_pin_v085', {
    p_token: token,
    p_event_id: eventId,
    p_pin: cleanPin,
  });

  if (error) throw new Error(error.message || 'עדכון הקוד נכשל.');
}

export async function updateEvent(
  token: string,
  eventId: string,
  values: {
    name: string;
    eventType: string;
    eventDate?: string | null;
    location?: string;
    status: EventStatus;
    coverImage?: string | null;
    eventEndsLocal?: string | null;
  },
) {
  const { data, error } = await supabase.rpc('update_event_v08', {
    p_token: token,
    p_event_id: eventId,
    p_name: values.name,
    p_event_type: values.eventType,
    p_event_date: values.eventDate || null,
    p_location: values.location || null,
    p_status: values.status,
    p_cover_image: values.coverImage ?? null,
    p_event_ends_local: values.eventEndsLocal || null,
  });

  if (error) throw error;
  const row = Array.isArray(data) ? data[0] : data;
  if (!row?.id) throw new Error('השמירה נכשלה.');
  return row as EventRow;
}

export async function moderatePhoto(
  token: string,
  photoId: string,
  status: PhotoStatus,
  expectedStatus?: PhotoStatus,
) {
  const response = await fetch('/api/staff/moderate', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ token, photoId, status, expectedStatus: expectedStatus || null }),
  });
  const payload = await response.json();
  if (!response.ok) throw new Error(payload?.error || 'הפעולה נכשלה.');
}

export async function getEventStats(token: string, eventId: string) {
  const { data, error } = await supabase.rpc('event_stats_v04', {
    p_token: token,
    p_event_id: eventId,
  });
  if (error) throw error;
  const row = Array.isArray(data) ? data[0] : data;
  return (row || {
    total: 0,
    pending: 0,
    approved: 0,
    private_count: 0,
    rejected: 0,
    storage_bytes: 0,
  }) as EventStats;
}

export async function getEventHealth(token: string, eventId: string) {
  const { data, error } = await supabase.rpc('event_health', {
    p_token: token,
    p_event_id: eventId,
  });
  if (error) throw error;
  const row = Array.isArray(data) ? data[0] : data;
  return (row || {
    moderator_ready: false,
    settings_ready: false,
    cover_ready: false,
    public_link_ready: false,
  }) as EventHealth;
}

export async function deletePhotoPermanent(token: string, eventId: string, photoId: string) {
  const response = await fetch('/api/admin/delete-photo', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ token, eventId, photoId }),
  });
  const payload = await response.json();
  if (!response.ok) throw new Error(payload?.error || 'המחיקה נכשלה.');
}
