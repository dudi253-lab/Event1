import fs from 'node:fs';

const read = (p) => fs.readFileSync(new URL(p, import.meta.url), 'utf8');
const checks = [];
const assert = (name, ok) => { checks.push([name, Boolean(ok)]); if (!ok) throw new Error(`FAILED: ${name}`); };

const api = read('./lib/event-api.ts');
const auth = read('./lib/supabase-admin.ts');
const pin = read('./app/api/staff/pin/route.ts');
const media = read('./app/api/media/route.ts');
const moderate = read('./app/api/staff/moderate/route.ts');
const del = read('./app/api/admin/delete-photo/route.ts');
const ticket = read('./app/api/upload-ticket/route.ts');
const sql = read('./supabase/v0.8.sql');
const layout = read('./app/layout.tsx');
const css = read('./app/globals.css');
const guest = read('./app/e/[event]/page.tsx');
const modPage = read('./app/e/[event]/moderator/page.tsx');
const adminPage = read('./app/admin/page.tsx');

assert('direct server session lookup', auth.includes(".from('staff_sessions')"));
assert('direct admin membership lookup', auth.includes(".from('company_users')"));
assert('direct moderator membership lookup', auth.includes(".from('event_staff')"));
assert('PIN route uses central resolver', pin.includes("getValidStaffSession(token, eventId, ['company_admin'])"));
assert('PIN writer is service-only v083', pin.includes('digi_set_event_moderator_pin_v083'));
assert('v083 repairs missing moderator', sql.includes("'digi-event-' || p_event_id::text"));
assert('canonical moderator secrets exist', sql.includes('event_moderator_secrets'));
assert('old moderator sessions revoked', sql.includes("role = 'photo_moderator'"));
assert('guest upload uses proven direct RLS insert', api.includes("supabase.from('photos').insert"));
assert('guest upload does not call complete-upload', !api.includes("fetch('/api/complete-upload'"));
assert('guest RLS enforces deadline', sql.includes('now() < e.event_ends_at'));
assert('ticket enforces deadline', ticket.includes("code: 'EVENT_ENDED'"));
assert('media uses shared auth', media.includes('validStaffToken'));
assert('moderation uses shared auth', moderate.includes('getValidStaffSession'));
assert('delete uses shared auth', del.includes('validStaffToken'));
assert('admin photo approval exists', adminPage.includes("adminModerate(photo, 'approved')"));
assert('guest countdown exists', guest.includes('variant="hero"'));
assert('moderator countdown exists', modPage.includes('variant="moderator"'));
assert('admin countdown exists', adminPage.includes('variant="admin"'));
assert('Frank font loaded', layout.includes('Frank_Ruhl_Libre') && layout.includes('--font-frank'));
assert('Heebo loaded', layout.includes('Heebo') && layout.includes('--font-heebo'));
assert('hero uses loaded serif', css.includes('font-family:var(--font-frank)'));

console.log(`✅ Digi v0.8.3 structural preflight passed (${checks.length}/${checks.length})`);
