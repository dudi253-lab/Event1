import { createClient } from '@supabase/supabase-js';

function serverConfig() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL?.trim() || '';
  const serviceKey =
    process.env.SUPABASE_SECRET_KEY?.trim() ||
    process.env.SUPABASE_SERVICE_ROLE_KEY?.trim() ||
    '';

  return { url, serviceKey };
}

export function getSupabaseAdmin() {
  const { url, serviceKey } = serverConfig();

  if (!url || !serviceKey) {
    throw new Error('Digi server configuration is incomplete. Missing Supabase URL or server secret.');
  }

  return createClient(url, serviceKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
      detectSessionInUrl: false,
    },
  });
}

export function getServerConfigHealth() {
  const { url, serviceKey } = serverConfig();
  return {
    urlConfigured: Boolean(url),
    secretConfigured: Boolean(serviceKey),
    secretKind: serviceKey.startsWith('sb_secret_')
      ? 'secret'
      : serviceKey.startsWith('eyJ')
        ? 'legacy-service-role'
        : serviceKey
          ? 'unknown'
          : 'missing',
  };
}

export type ValidStaffSession = {
  token: string;
  user_id: string;
  event_id: string | null;
  role: 'company_admin' | 'photo_moderator';
};

export async function getValidStaffSession(
  token: string,
  eventId: string,
  allowedRoles: Array<'company_admin' | 'photo_moderator'>,
): Promise<ValidStaffSession | null> {
  if (!token || !eventId || !allowedRoles.length) return null;

  const admin = getSupabaseAdmin();
  const { data, error } = await admin.rpc('digi_valid_staff_v07', {
    p_token: token,
    p_event_id: eventId,
    p_roles: allowedRoles,
  });

  if (error) {
    console.error('digi_valid_staff_v07', error);
    return null;
  }

  const row = Array.isArray(data) ? data[0] : data;
  if (!row?.token || !row?.user_id || !row?.role) return null;

  return {
    token: String(row.token),
    user_id: String(row.user_id),
    event_id: row.event_id ? String(row.event_id) : null,
    role: row.role as 'company_admin' | 'photo_moderator',
  };
}

export async function validStaffToken(
  token: string,
  eventId: string,
  allowedRoles: Array<'company_admin' | 'photo_moderator'>,
) {
  return Boolean(await getValidStaffSession(token, eventId, allowedRoles));
}
